# Student Loan Payoff Planner — Deploy Guide

## How to deploy (no coding needed)

### Step 1 — Create a free GitHub account
Go to github.com and sign up (free). Skip if you already have one.

### Step 2 — Create a new GitHub repository
1. Click the green "New" button on github.com
2. Name it: `student-loan-planner`
3. Set to Public
4. Click "Create repository"

### Step 3 — Upload these files to GitHub
1. On your new repo page, click "uploading an existing file"
2. Drag ALL the files and folders from this zip into the upload area
   - index.html
   - package.json
   - vite.config.js
   - src/ (folder)
   - netlify/ (folder)
   - netlify.toml
3. Click "Commit changes"

### Step 4 — Connect Netlify to GitHub
1. Go to app.netlify.com → "Add new site" → "Import an existing project"
2. Choose GitHub → Select your `student-loan-planner` repo
3. Build settings are auto-detected from netlify.toml:
   - Build command: `npm install && npm run build`
   - Publish directory: `dist`
4. Click "Deploy site"

### Step 5 — Add your Anthropic API key
1. In Netlify: Site configuration → Environment variables
2. Add variable:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...` (your key from console.anthropic.com)
3. Trigger a redeploy: Deploys → "Trigger deploy"

### Your live URL
`https://student-loan-planner.netlify.app`

Share this with anyone — the AI features work for all users,
your API key stays hidden on the server.
