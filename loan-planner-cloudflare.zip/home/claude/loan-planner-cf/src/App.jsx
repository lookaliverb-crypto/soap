import React, { useState, useMemo, useCallback, useEffect, useRef } from "react";


const GOOGLE_FONTS = `@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,400;0,600;0,700;0,900;1,400;1,700&family=Nunito:wght@300;400;500;600;700&display=swap');`;

// ── Lightweight SVG Area Chart (replaces Recharts ~430KB) ──
function MiniAreaChart({ data, series, height = 220 }) {
  if (!data || data.length < 2) return null;
  const W = 600, H = height, PL = 48, PR = 12, PT = 10, PB = 32;
  const cW = W - PL - PR, cH = H - PT - PB;
  const keys = series.map(s => s.key);
  const allVals = data.flatMap(d => keys.map(k => d[k] || 0));
  const maxV = Math.max(...allVals) || 1;
  const px = i => PL + (i / (data.length - 1)) * cW;
  const py = v => PT + cH - (v / maxV) * cH;
  // Y axis ticks
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(t => ({ v: maxV * t, y: py(maxV * t) }));
  // X axis ticks (up to 6)
  const step = Math.ceil(data.length / 6);
  const xTicks = data.filter((_, i) => i % step === 0 || i === data.length - 1);
  const fmt = v => v >= 1000 ? "$" + (v / 1000).toFixed(0) + "k" : "$" + v;
  return (
    <svg viewBox={"0 0 " + W + " " + H} style={{width:"100%",height,overflow:"visible"}} role="img">
      <defs>
        {series.map(s => (
          <linearGradient key={s.key} id={"g_" + s.key.replace(/[^a-z]/gi,"_")} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={s.color} stopOpacity={0.18}/>
            <stop offset="95%" stopColor={s.color} stopOpacity={0}/>
          </linearGradient>
        ))}
      </defs>
      {/* Grid lines */}
      {yTicks.map((t, i) => (
        <line key={i} x1={PL} x2={W - PR} y1={t.y} y2={t.y} stroke="rgba(169,154,146,0.15)" strokeWidth={1}/>
      ))}
      {/* Y axis labels */}
      {yTicks.map((t, i) => (
        <text key={i} x={PL - 6} y={t.y + 4} textAnchor="end" fontSize={10} fill="#A99A92" fontFamily="Nunito">{fmt(t.v)}</text>
      ))}
      {/* X axis labels */}
      {xTicks.map((d, i) => (
        <text key={i} x={px(data.indexOf(d))} y={H - 4} textAnchor="middle" fontSize={10} fill="#A99A92" fontFamily="Nunito">{d.month}</text>
      ))}
      {/* Area fills then lines */}
      {series.map(s => {
        const pts = data.map((d, i) => px(i) + "," + py(d[s.key] || 0));
        const linePath = "M " + pts.join(" L ");
        const areaPath = linePath + " L " + px(data.length-1) + "," + (PT+cH) + " L " + PL + "," + (PT+cH) + " Z";
        return (
          <g key={s.key}>
            <path d={areaPath} fill={"url(#g_" + s.key.replace(/[^a-z]/gi,"_") + ")"} />
            <path d={linePath} fill="none" stroke={s.color} strokeWidth={s.width || 2} strokeLinejoin="round" strokeLinecap="round"/>
          </g>
        );
      })}
      {/* Legend */}
      {series.map((s, i) => (
        <g key={s.key} transform={"translate(" + (PL + i * 130) + "," + (H - 2) + ")"}>
          <line x1={0} x2={16} y1={-8} y2={-8} stroke={s.color} strokeWidth={2.5} strokeLinecap="round"/>
          <text x={20} y={-4} fontSize={10} fill="#6B5B52" fontFamily="Nunito">{s.label}</text>
        </g>
      ))}
    </svg>
  );
}

const css = `
${GOOGLE_FONTS}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --cream:#FAF7F2;--warm-white:#FFFDF9;
  --terracotta:#D96C45;--terracotta-light:#F0A882;
  --sage:#5A8A6A;--sage-light:#8ABD98;
  --blue:#5B7FA6;--blue-light:#A0BDD4;
  --purple:#7C5CBF;--purple-light:#B8A0E0;
  --gold:#C89A2A;--gold-light:#E8C96A;
  --pink:#C05A8A;--pink-light:#E0A0C0;
  --text-dark:#2D2420;--text-mid:#6B5B52;--text-light:#A99A92;
  --border:rgba(217,108,69,0.12);
  --shadow-sm:0 2px 12px rgba(180,100,60,0.08);
  --shadow-md:0 8px 32px rgba(180,100,60,0.12);
  --shadow-lg:0 20px 50px rgba(180,100,60,0.15);
}
body{background:var(--cream);font-family:'Nunito',sans-serif;}
.app{min-height:100vh;background:var(--cream);position:relative;overflow-x:hidden;}

/* ── DARK MODE ── */
[data-dark]{
  --cream:#1A1714;--warm-white:#242018;
  --terracotta:#E8845A;--terracotta-light:#C06040;
  --sage:#6AAA7A;--sage-light:#4A7A5A;
  --blue:#7A9FC6;--blue-light:#4A6A8A;
  --purple:#9A7ADF;--purple-light:#6A4AAA;
  --gold:#D8B040;--gold-light:#A88020;
  --pink:#D07AA0;--pink-light:#A04A70;
  --text-dark:#F0EAE0;--text-mid:#B8A898;--text-light:#706050;
  --border:rgba(232,132,90,0.18);
  --shadow-sm:0 2px 12px rgba(0,0,0,0.35);
  --shadow-md:0 8px 32px rgba(0,0,0,0.45);
  --shadow-lg:0 20px 50px rgba(0,0,0,0.55);
}
[data-dark] .blob-1{background:#5A2A18;}
[data-dark] .blob-2{background:#1A3A28;}
[data-dark] .blob-3{background:#2A1A10;}
[data-dark] input[type="text"],[data-dark] input[type="number"],[data-dark] input[type="date"]{background:#2A2420;color:var(--text-dark);}
[data-dark] input:focus{background:#322820;}
[data-dark] .fed-field select,[data-dark] .forgive-field select{background:#2A2420;color:var(--text-dark);}
[data-dark] .upload-zone{background:#201C18;}
[data-dark] .upload-file-chip,[data-dark] .add-checkin,[data-dark] .whatif-tile,[data-dark] .salary-tile,[data-dark] .partner-res-tile,[data-dark] .tax-stat,[data-dark] .cal-month,[data-dark] .hustle-chip,[data-dark] .amort-sum-tile,[data-dark] .payoff-step-body,[data-dark] .csv-zone{background:#2A2420;}
[data-dark] thead tr,[data-dark] .h2h-verdict,[data-dark] .budget-breakdown,[data-dark] .hustle-impact,[data-dark] .fed-plan-card.neutral,[data-dark] .fed-plan-card.caution,[data-dark] .forgive-program-card.unlikely,[data-dark] .refi-current-card,[data-dark] .lender-card,[data-dark] .strat-card,.strat-card,[data-dark] .summary-tile{background:#2A2420;}
[data-dark] .ct{background:#2A2420;border-color:rgba(232,132,90,0.18);}

/* ── TOOLBAR (dark toggle + share + print) ── */
.toolbar{position:fixed;top:1rem;right:1rem;z-index:100;display:flex;gap:0.5rem;}
.toolbar-btn{width:38px;height:38px;border-radius:50%;border:1.5px solid var(--border);background:var(--warm-white);box-shadow:var(--shadow-sm);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:transform 0.15s,box-shadow 0.15s;color:var(--text-mid);}
.toolbar-btn:hover{transform:scale(1.1);box-shadow:var(--shadow-md);}
.share-toast{position:fixed;top:4rem;right:1rem;background:var(--sage);color:white;padding:0.55rem 1.2rem;border-radius:999px;font-size:0.8rem;font-weight:700;z-index:200;animation:toastIn 0.3s cubic-bezier(0.34,1.56,0.64,1) both,toastOut 0.3s ease 2.2s forwards;}
@keyframes toastIn{from{opacity:0;transform:translateY(-8px) scale(0.9);}to{opacity:1;transform:none;}}
@keyframes toastOut{to{opacity:0;transform:translateY(-8px);}}

/* ── CSV IMPORT ── */
.csv-zone{border:2px dashed rgba(90,138,106,0.35);border-radius:20px;padding:1.5rem;text-align:center;cursor:pointer;transition:all 0.25s;background:rgba(90,138,106,0.03);position:relative;margin-bottom:1rem;}
.csv-zone:hover,.csv-zone.drag-over{border-color:var(--sage);background:rgba(90,138,106,0.07);}
.csv-zone input[type="file"]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
.csv-result{background:rgba(90,138,106,0.06);border:1.5px solid rgba(90,138,106,0.22);border-radius:18px;padding:1.1rem 1.4rem;margin-bottom:1rem;}
.csv-result-title{font-family:'Fraunces',serif;font-size:0.9rem;font-weight:700;color:var(--sage);margin-bottom:0.75rem;}
.csv-cats{display:grid;grid-template-columns:1fr 1fr;gap:0.4rem 1.5rem;margin-bottom:0.75rem;max-height:180px;overflow-y:auto;}
.csv-cat-row{display:flex;justify-content:space-between;font-size:0.8rem;padding:0.25rem 0;border-bottom:1px solid rgba(90,138,106,0.1);}
.csv-cat-name{color:var(--text-mid);}.csv-cat-amt{font-weight:700;color:var(--text-dark);}
.csv-surplus-row{display:flex;justify-content:space-between;align-items:center;padding-top:0.7rem;border-top:2px solid rgba(90,138,106,0.2);}
.csv-surplus-label{font-family:'Fraunces',serif;font-size:0.9rem;font-weight:700;color:var(--text-dark);}
.csv-surplus-val{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:900;}

/* ── PAYOFF ORDER ── */
.payoff-order-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.payoff-timeline{display:flex;flex-direction:column;}
.payoff-step{display:grid;grid-template-columns:48px 1fr;gap:1rem;align-items:stretch;}
.payoff-step-left{display:flex;flex-direction:column;align-items:center;}
.payoff-step-num{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Fraunces',serif;font-size:0.9rem;font-weight:900;color:white;flex-shrink:0;}
.payoff-step-line{flex:1;width:2px;background:var(--border);margin:4px auto;}
.payoff-step-body{background:var(--cream);border-radius:18px;padding:1rem 1.25rem;margin-bottom:0.75rem;}
.payoff-step-title{font-family:'Fraunces',serif;font-size:1rem;font-weight:800;color:var(--text-dark);margin-bottom:0.2rem;}
.payoff-step-date{font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);margin-bottom:0.5rem;}
.payoff-step-stats{display:flex;gap:1.5rem;flex-wrap:wrap;}
.payoff-step-stat{font-size:0.8rem;color:var(--text-mid);}
.payoff-step-stat strong{color:var(--text-dark);font-weight:700;}
.payoff-step-action{margin-top:0.5rem;font-size:0.8rem;color:var(--sage);font-weight:700;}

/* ── AMORTIZATION TABLE ── */
.amort-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.amort-tabs{display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1.25rem;}
.amort-tab{padding:0.4rem 1rem;border-radius:999px;border:2px solid var(--border);background:var(--cream);font-size:0.8rem;font-weight:700;cursor:pointer;transition:all 0.2s;color:var(--text-mid);}
.amort-tab:hover{border-color:var(--blue);}
.amort-tab.active{border-color:var(--blue);background:rgba(91,127,166,0.12);color:var(--blue);}
.amort-table-wrap{overflow-x:auto;border-radius:16px;border:1.5px solid var(--border);}
table{width:100%;border-collapse:collapse;font-size:0.8rem;}
thead tr{background:var(--cream);}
th{padding:0.65rem 1rem;text-align:right;font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);white-space:nowrap;}
th:first-child{text-align:left;}
td{padding:0.6rem 1rem;text-align:right;border-top:1px solid var(--border);color:var(--text-mid);}
td:first-child{text-align:left;font-weight:600;color:var(--text-dark);}
tr:hover td{background:rgba(91,127,166,0.04);}
.td-interest{color:#c0402a;font-weight:600;}
.td-principal{color:var(--sage);font-weight:600;}
.amort-pagination{display:flex;align-items:center;justify-content:space-between;margin-top:1rem;font-size:0.8rem;color:var(--text-light);}
.amort-summary-row{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.25rem;}
.amort-sum-tile{background:var(--cream);border-radius:16px;padding:0.85rem 1.1rem;}
.amort-sum-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.2rem;}
.amort-sum-val{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:900;color:var(--text-dark);}
.amort-sum-val.red{color:#c0402a;}.amort-sum-val.green{color:var(--sage);}

/* ── PRINT ── */
@media print{
  .blob,.toolbar,.btn-cta,.btn-parse,.btn-refi,.btn-fed,.btn-forgive,.btn-log,.add-checkin,.whatif-card,.hustle-card,.partner-card,.salary-card,.forgive-card,.calendar-card,.refi-section,.fed-section,.progress-card,.h2h-card{display:none!important;}
  .app,.inner{background:white!important;}
  .inner{padding:0!important;max-width:100%!important;}
  .card,.amort-card,.payoff-order-card,.tax-card{box-shadow:none!important;border:1px solid #ddd!important;break-inside:avoid;margin-bottom:0.75rem!important;padding:1.25rem!important;}
  h1{font-size:2rem!important;}
  .results{animation:none!important;}
  table{font-size:0.7rem!important;}
}
.blob{position:fixed;border-radius:50%;filter:blur(80px);opacity:0.35;pointer-events:none;z-index:0;}
.blob-1{width:500px;height:500px;background:#F5C4A8;top:-150px;right:-100px;}
.blob-2{width:400px;height:400px;background:#C5DBC9;bottom:10%;left:-100px;}
.blob-3{width:300px;height:300px;background:#F0D9CC;top:40%;right:5%;}
.inner{position:relative;z-index:1;max-width:960px;margin:0 auto;padding:0 1.5rem 5rem;}

.header{padding:3.5rem 0 2rem;text-align:center;}
.header-badge{display:inline-flex;align-items:center;gap:0.5rem;background:var(--warm-white);border:1px solid var(--border);border-radius:999px;padding:0.35rem 1rem;font-size:0.78rem;font-weight:600;color:var(--terracotta);margin-bottom:1.5rem;box-shadow:var(--shadow-sm);}
.header-badge::before{content:'✦';font-size:0.65rem;}
h1{font-family:'Fraunces',serif;font-size:clamp(2.4rem,5.5vw,4rem);font-weight:900;color:var(--text-dark);line-height:1.1;letter-spacing:-0.02em;margin-bottom:0.75rem;}
h1 em{font-style:italic;color:var(--terracotta);}
.header-sub{color:var(--text-mid);font-size:1.05rem;max-width:520px;margin:0 auto;line-height:1.6;}

.card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.section-label{font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:var(--text-dark);margin-bottom:1.25rem;display:flex;align-items:center;gap:0.6rem;}
.icon-badge{width:32px;height:32px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:0.85rem;flex-shrink:0;}
.icon-badge.orange{background:linear-gradient(135deg,var(--terracotta-light),var(--terracotta));}
.icon-badge.blue{background:linear-gradient(135deg,var(--blue-light),var(--blue));}
.icon-badge.sage{background:linear-gradient(135deg,var(--sage-light),var(--sage));}
.icon-badge.purple{background:linear-gradient(135deg,var(--purple-light),var(--purple));}
.icon-badge.gold{background:linear-gradient(135deg,var(--gold-light),var(--gold));}
.icon-badge.pink{background:linear-gradient(135deg,var(--pink-light),var(--pink));}

/* Upload */
.upload-zone{border:2px dashed rgba(217,108,69,0.3);border-radius:20px;padding:2rem 1.5rem;text-align:center;cursor:pointer;transition:all 0.25s;background:var(--cream);position:relative;margin-bottom:1rem;}
.upload-zone.blue-zone{border-color:rgba(91,127,166,0.3);}
.upload-zone:hover,.upload-zone.drag-over{border-color:var(--terracotta);background:rgba(217,108,69,0.04);}
.upload-zone.blue-zone:hover,.upload-zone.blue-zone.drag-over{border-color:var(--blue);background:rgba(91,127,166,0.04);}
.upload-zone input[type="file"]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;border:none;padding:0;background:none;border-radius:0;}
.upload-icon{font-size:2.2rem;margin-bottom:0.6rem;}
.upload-title{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);margin-bottom:0.3rem;}
.upload-sub{font-size:0.8rem;color:var(--text-light);line-height:1.5;}
.upload-sub strong{color:var(--terracotta);}
.upload-sub strong.blue{color:var(--blue);}
.upload-files-list{display:flex;flex-direction:column;gap:0.5rem;margin-bottom:0.75rem;}
.upload-file-chip{display:flex;align-items:center;gap:0.75rem;background:var(--cream);border-radius:14px;padding:0.6rem 1rem;font-size:0.84rem;color:var(--text-mid);font-weight:500;}
.file-icon{font-size:1rem;}.file-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.remove-file{background:none;border:none;color:var(--text-light);cursor:pointer;font-size:1.1rem;padding:0 0.2rem;line-height:1;transition:color 0.15s;}
.remove-file:hover{color:var(--terracotta);}
.btn-parse{width:100%;padding:0.8rem;background:linear-gradient(135deg,#5B7FA6,#3D6090);color:white;border:none;border-radius:16px;font-family:'Fraunces',serif;font-size:0.95rem;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(91,127,166,0.3);transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-bottom:0.75rem;}
.btn-parse:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 28px rgba(91,127,166,0.4);}
.btn-parse:disabled{opacity:0.6;cursor:not-allowed;}
.parsing-state{display:flex;flex-direction:column;align-items:center;gap:0.75rem;padding:1.25rem;text-align:center;}
.spinner{width:36px;height:36px;border:3px solid rgba(217,108,69,0.15);border-top-color:var(--terracotta);border-radius:50%;animation:spin 0.8s linear infinite;}
.spinner.blue{border-color:rgba(91,127,166,0.15);border-top-color:var(--blue);}
.spinner.purple{border-color:rgba(124,92,191,0.15);border-top-color:var(--purple);}
.spinner.gold{border-color:rgba(200,154,42,0.15);border-top-color:var(--gold);}
@keyframes spin{to{transform:rotate(360deg);}}
.parsing-label{font-family:'Fraunces',serif;font-size:0.95rem;color:var(--text-dark);}
.parsing-sub{font-size:0.78rem;color:var(--text-light);}
.parse-success{display:flex;align-items:flex-start;gap:0.75rem;background:rgba(90,138,106,0.08);border:1.5px solid rgba(90,138,106,0.25);border-radius:16px;padding:0.9rem 1.2rem;margin-bottom:0.75rem;}
.parse-success-icon{font-size:1.2rem;flex-shrink:0;}
.parse-success-text{font-size:0.84rem;color:var(--sage);font-weight:600;line-height:1.5;}
.parse-success-text span{display:block;font-weight:400;color:var(--text-light);font-size:0.77rem;margin-top:0.15rem;}
.parse-error{display:flex;align-items:flex-start;gap:0.75rem;background:rgba(192,80,46,0.07);border:1.5px solid rgba(192,80,46,0.2);border-radius:16px;padding:0.9rem 1.2rem;margin-bottom:0.75rem;}
.parse-error-icon{font-size:1.2rem;flex-shrink:0;}
.parse-error-text{font-size:0.83rem;color:#b04030;line-height:1.5;}
.divider-row{display:flex;align-items:center;gap:0.75rem;margin:1.5rem 0;}
.divider-line{flex:1;height:1px;background:var(--border);}
.divider-text{font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--text-light);}
.budget-breakdown{background:rgba(91,127,166,0.05);border:1.5px solid rgba(91,127,166,0.18);border-radius:20px;padding:1.25rem;margin-bottom:1rem;}
.budget-breakdown-title{font-family:'Fraunces',serif;font-size:0.95rem;font-weight:700;color:var(--blue);margin-bottom:1rem;}
.budget-row-grid{display:grid;grid-template-columns:1fr 1fr;gap:0.5rem 1.5rem;margin-bottom:0.75rem;}
.budget-item{display:flex;justify-content:space-between;font-size:0.82rem;padding:0.35rem 0;border-bottom:1px solid rgba(91,127,166,0.1);}
.budget-item-label{color:var(--text-mid);}.budget-item-val{font-weight:700;color:var(--text-dark);}
.budget-surplus-row{display:flex;justify-content:space-between;align-items:center;padding-top:0.75rem;border-top:2px solid rgba(91,127,166,0.2);margin-top:0.5rem;}
.budget-surplus-label{font-family:'Fraunces',serif;font-size:0.95rem;font-weight:700;color:var(--text-dark);}
.budget-surplus-val{font-family:'Fraunces',serif;font-size:1.4rem;font-weight:900;color:var(--sage);}
.budget-surplus-val.tight{color:var(--terracotta);}
.col-heads{display:grid;grid-template-columns:2fr 1.2fr 1.2fr 1.2fr 36px;gap:0.75rem;padding:0 0.5rem;margin-bottom:0.5rem;}
.col-head{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);}
.loans-list{display:flex;flex-direction:column;gap:0.6rem;margin-bottom:1rem;}
.loan-row{display:grid;grid-template-columns:2fr 1.2fr 1.2fr 1.2fr 36px;gap:0.75rem;align-items:center;}
.loan-row.new-loan{animation:slideIn 0.35s cubic-bezier(0.34,1.56,0.64,1) both;}
@keyframes slideIn{from{opacity:0;transform:translateY(-8px) scale(0.98);}to{opacity:1;transform:none;}}
input[type="text"],input[type="number"]{width:100%;background:var(--cream);border:1.5px solid transparent;border-radius:14px;padding:0.68rem 1rem;font-family:'Nunito',sans-serif;font-size:0.9rem;font-weight:500;color:var(--text-dark);outline:none;transition:border-color 0.2s,box-shadow 0.2s,background 0.2s;}
input::placeholder{color:var(--text-light);}
input:focus{border-color:var(--terracotta-light);background:var(--warm-white);box-shadow:0 0 0 3px rgba(217,108,69,0.1);}
input.highlighted{border-color:var(--sage);background:rgba(90,138,106,0.04);}
.btn-remove{width:34px;height:34px;border-radius:50%;border:none;background:#FDE8E0;color:var(--terracotta);font-size:1.1rem;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background 0.2s,transform 0.15s;}
.btn-remove:hover{background:#FACBB5;transform:scale(1.08);}
.btn-add{display:inline-flex;align-items:center;gap:0.4rem;background:none;border:2px dashed rgba(217,108,69,0.3);border-radius:14px;color:var(--terracotta);padding:0.5rem 1.2rem;font-family:'Nunito',sans-serif;font-weight:600;font-size:0.84rem;cursor:pointer;transition:background 0.2s,border-color 0.2s;}
.btn-add:hover{background:rgba(217,108,69,0.05);border-color:var(--terracotta);}
.manual-budget-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-top:1.25rem;padding-top:1.25rem;border-top:1.5px dashed rgba(217,108,69,0.15);}
.field-group label{display:block;font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.4rem;}
.field-hint{font-size:0.72rem;color:var(--text-light);margin-top:0.3rem;}
.field-hint.green{color:var(--sage);font-weight:600;}
.btn-cta{width:100%;margin-top:1.5rem;padding:1rem;background:linear-gradient(135deg,var(--terracotta),#C0502E);color:white;border:none;border-radius:18px;font-family:'Fraunces',serif;font-size:1.05rem;font-weight:700;cursor:pointer;box-shadow:0 8px 24px rgba(217,108,69,0.35);transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.btn-cta:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(217,108,69,0.45);}
.results{animation:popIn 0.45s cubic-bezier(0.34,1.56,0.64,1) both;}
@keyframes popIn{from{opacity:0;transform:scale(0.97) translateY(16px);}to{opacity:1;transform:scale(1) translateY(0);}}
.summary-row{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.5rem;}
.summary-tile{background:var(--warm-white);border-radius:22px;padding:1.2rem 1.4rem;border:1px solid rgba(255,255,255,0.8);box-shadow:var(--shadow-sm);}
.tile-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);margin-bottom:0.3rem;}
.tile-value{font-family:'Fraunces',serif;font-size:1.75rem;font-weight:900;color:var(--text-dark);line-height:1;}
.tile-value.green{color:var(--sage);}
.tile-sub{font-size:0.75rem;color:var(--text-light);margin-top:0.3rem;}
.h2h-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-lg);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;overflow:hidden;}
.h2h-title{font-family:'Fraunces',serif;font-size:1.5rem;font-weight:900;color:var(--text-dark);text-align:center;margin-bottom:0.4rem;}
.h2h-sub{text-align:center;font-size:0.83rem;color:var(--text-light);margin-bottom:2rem;}
.h2h-grid{display:grid;grid-template-columns:1fr auto 1fr;gap:1rem;align-items:start;margin-bottom:1.5rem;}
.h2h-side{border-radius:22px;padding:1.5rem;position:relative;}
.h2h-side.avalanche{background:linear-gradient(145deg,rgba(217,108,69,0.07),rgba(217,108,69,0.03));border:2px solid rgba(217,108,69,0.25);}
.h2h-side.snowball{background:linear-gradient(145deg,rgba(91,127,166,0.07),rgba(91,127,166,0.03));border:2px solid rgba(91,127,166,0.25);}
.h2h-side.winner.avalanche{border-color:var(--terracotta);box-shadow:0 8px 30px rgba(217,108,69,0.2);}
.h2h-side.winner.snowball{border-color:var(--blue);box-shadow:0 8px 30px rgba(91,127,166,0.2);}
.winner-crown{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--terracotta);color:white;font-size:0.6rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;padding:0.25rem 0.9rem;border-radius:999px;white-space:nowrap;}
.winner-crown.blue{background:var(--blue);}
.h2h-method-name{font-family:'Fraunces',serif;font-size:1.15rem;font-weight:800;margin-bottom:0.2rem;}
.h2h-method-name.orange{color:var(--terracotta);}
.h2h-method-name.blue-c{color:var(--blue);}
.h2h-method-tag{font-size:0.75rem;color:var(--text-light);margin-bottom:1.1rem;line-height:1.4;}
.h2h-stat{margin-bottom:0.6rem;}
.h2h-stat-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);margin-bottom:0.15rem;}
.h2h-stat-val{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:800;color:var(--text-dark);}
.h2h-stat-val.highlight-orange{color:var(--terracotta);}
.h2h-stat-val.highlight-blue{color:var(--blue);}
.h2h-stat-val.green{color:var(--sage);}
.h2h-stat-val.red{color:#c0402a;}
.h2h-vs{display:flex;align-items:center;justify-content:center;}
.vs-circle{width:52px;height:52px;border-radius:50%;background:var(--cream);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-family:'Fraunces',serif;font-size:0.9rem;font-weight:900;color:var(--text-light);margin-top:2.5rem;}
.h2h-verdict{background:var(--cream);border-radius:18px;padding:1.25rem 1.5rem;text-align:center;}
.verdict-title{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);margin-bottom:0.4rem;}
.verdict-text{font-size:0.84rem;color:var(--text-mid);line-height:1.6;}
.verdict-winner-pill{display:inline-flex;align-items:center;gap:0.4rem;border-radius:999px;padding:0.2rem 0.8rem;font-size:0.8rem;font-weight:700;margin-bottom:0.5rem;}
.verdict-winner-pill.orange{background:rgba(217,108,69,0.12);color:var(--terracotta);}
.verdict-winner-pill.blue-p{background:rgba(91,127,166,0.12);color:var(--blue);}
.strategies-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;margin-bottom:1.5rem;}
.strat-card{background:var(--warm-white);border-radius:24px;padding:1.4rem;box-shadow:var(--shadow-sm);border:2px solid transparent;position:relative;overflow:hidden;transition:box-shadow 0.2s,transform 0.2s;}
.strat-card:hover{box-shadow:var(--shadow-md);transform:translateY(-2px);}
.strat-card.featured{border-color:var(--terracotta);background:linear-gradient(145deg,#FFFDF9,#FFF4EE);}
.strat-card.featured-blue{border-color:var(--blue);background:linear-gradient(145deg,#FFFDF9,#F0F5FA);}
.feat-ribbon{position:absolute;top:14px;right:-26px;color:white;font-size:0.58rem;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:0.25rem 2rem;transform:rotate(35deg);}
.feat-ribbon.orange{background:var(--terracotta);}.feat-ribbon.blue-r{background:var(--blue);}
.strat-emoji{font-size:1.5rem;margin-bottom:0.55rem;}
.strat-name{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);margin-bottom:0.25rem;}
.strat-desc{font-size:0.77rem;color:var(--text-mid);line-height:1.5;margin-bottom:0.9rem;}
.strat-stats{display:flex;flex-direction:column;gap:0.4rem;}
.strat-stat{display:flex;justify-content:space-between;font-size:0.81rem;}
.ss-label{color:var(--text-light);}
.ss-val{font-weight:700;color:var(--text-dark);}
.ss-val.accent{color:var(--terracotta);}.ss-val.blue-v{color:var(--blue);}.ss-val.green{color:var(--sage);}.ss-val.red{color:#C0402A;}
.divider-stat{height:1px;background:var(--border);margin:0.35rem 0;}
.chart-card-title{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:700;color:var(--text-dark);margin-bottom:0.3rem;}
.chart-sub{font-size:0.79rem;color:var(--text-light);margin-bottom:1.4rem;}
.ct{background:#FFFDF9;border:1px solid rgba(217,108,69,0.12);border-radius:14px;padding:0.85rem 1rem;font-family:'Nunito';font-size:0.78rem;}
.ct-label{color:var(--text-light);margin-bottom:0.3rem;font-size:0.72rem;}
.tips-grid{display:flex;flex-direction:column;gap:0.7rem;}
.tip-item{display:flex;gap:0.9rem;align-items:flex-start;background:var(--cream);border-radius:18px;padding:0.9rem 1.2rem;}
.tip-dot{width:8px;height:8px;border-radius:50%;background:var(--terracotta);flex-shrink:0;margin-top:0.35rem;}
.tip-text{font-size:0.84rem;color:var(--text-mid);line-height:1.55;}

/* ── WHAT-IF SIMULATOR ── */
.whatif-card{background:linear-gradient(145deg,#FFF8F0,#FFFDF9);border-radius:28px;box-shadow:var(--shadow-md);border:2px solid rgba(217,108,69,0.18);padding:2rem;margin-bottom:1.5rem;}
.whatif-sliders{display:flex;flex-direction:column;gap:1.5rem;margin-bottom:1.75rem;}
.slider-group label{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:0.6rem;}
.slider-label-text{font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-mid);}
.slider-label-val{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:900;color:var(--terracotta);}
.slider-label-val.blue{color:var(--blue);}
input[type="range"]{-webkit-appearance:none;appearance:none;width:100%;height:6px;border-radius:999px;background:var(--cream);outline:none;border:none;padding:0;cursor:pointer;}
input[type="range"]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:22px;height:22px;border-radius:50%;background:var(--terracotta);box-shadow:0 2px 8px rgba(217,108,69,0.4);cursor:pointer;transition:transform 0.15s;}
input[type="range"]::-webkit-slider-thumb:hover{transform:scale(1.15);}
input[type="range"].blue-thumb::-webkit-slider-thumb{background:var(--blue);box-shadow:0 2px 8px rgba(91,127,166,0.4);}
.whatif-results-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;}
.whatif-tile{background:var(--warm-white);border-radius:20px;padding:1.1rem 1.25rem;box-shadow:var(--shadow-sm);}
.whatif-tile-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);margin-bottom:0.3rem;}
.whatif-tile-val{font-family:'Fraunces',serif;font-size:1.5rem;font-weight:900;color:var(--text-dark);}
.whatif-tile-val.green{color:var(--sage);}
.whatif-tile-val.orange{color:var(--terracotta);}
.whatif-tile-delta{font-size:0.72rem;font-weight:700;margin-top:0.2rem;}
.whatif-tile-delta.better{color:var(--sage);}
.whatif-tile-delta.worse{color:var(--terracotta);}

/* ── SIDE HUSTLE ── */
.hustle-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.hustle-options{display:grid;grid-template-columns:repeat(3,1fr);gap:0.75rem;margin-bottom:1.5rem;}
.hustle-chip{padding:0.6rem 0.75rem;border-radius:16px;border:2px solid var(--border);background:var(--cream);cursor:pointer;text-align:center;transition:all 0.2s;}
.hustle-chip:hover{border-color:var(--terracotta);background:rgba(217,108,69,0.04);}
.hustle-chip.active{border-color:var(--terracotta);background:rgba(217,108,69,0.08);}
.hustle-chip-icon{font-size:1.4rem;margin-bottom:0.2rem;}
.hustle-chip-label{font-size:0.72rem;font-weight:700;color:var(--text-dark);}
.hustle-chip-earn{font-size:0.65rem;color:var(--text-light);}
.hustle-impact{background:linear-gradient(145deg,rgba(90,138,106,0.07),rgba(90,138,106,0.02));border:2px solid rgba(90,138,106,0.25);border-radius:22px;padding:1.5rem;margin-top:1rem;}
.hustle-impact-title{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--sage);margin-bottom:1rem;}
.hustle-impact-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:0.75rem;}
.hustle-stat-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.2rem;}
.hustle-stat-val{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:900;color:var(--sage);}

/* ── TAX DEDUCTION ── */
.tax-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.tax-bracket-row{display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1.25rem;}
.tax-bracket-btn{padding:0.4rem 0.85rem;border-radius:999px;border:2px solid var(--border);background:var(--cream);font-size:0.78rem;font-weight:700;color:var(--text-mid);cursor:pointer;transition:all 0.2s;}
.tax-bracket-btn:hover{border-color:var(--gold);}
.tax-bracket-btn.active{border-color:var(--gold);background:rgba(200,154,42,0.1);color:var(--gold);}
.tax-breakdown{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1rem;}
.tax-stat{background:var(--cream);border-radius:18px;padding:1rem 1.2rem;}
.tax-stat-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.25rem;}
.tax-stat-val{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:900;color:var(--text-dark);}
.tax-stat-val.gold{color:var(--gold);}
.tax-note{font-size:0.78rem;color:var(--text-light);line-height:1.55;}

/* ── PROGRESS TRACKER ── */
.progress-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.progress-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;}
.progress-header-text h3{font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:var(--text-dark);}
.progress-header-text p{font-size:0.78rem;color:var(--text-light);margin-top:0.2rem;}
.btn-sm{padding:0.45rem 1rem;border-radius:999px;font-family:'Nunito',sans-serif;font-size:0.78rem;font-weight:700;cursor:pointer;border:none;transition:all 0.2s;}
.btn-sm.sage{background:rgba(90,138,106,0.12);color:var(--sage);}
.btn-sm.sage:hover{background:rgba(90,138,106,0.2);}
.btn-sm.red{background:rgba(192,80,46,0.1);color:#c0402a;}
.btn-sm.red:hover{background:rgba(192,80,46,0.18);}
.overall-progress{margin-bottom:1.5rem;}
.progress-bar-track{height:14px;background:var(--cream);border-radius:999px;overflow:hidden;margin:0.5rem 0;}
.progress-bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,var(--sage-light),var(--sage));transition:width 0.8s cubic-bezier(0.34,1.2,0.64,1);}
.progress-bar-label{display:flex;justify-content:space-between;font-size:0.72rem;color:var(--text-light);}
.checkin-list{display:flex;flex-direction:column;gap:0.6rem;margin-bottom:1rem;max-height:280px;overflow-y:auto;}
.checkin-row{display:grid;grid-template-columns:120px 1fr auto auto;gap:0.75rem;align-items:center;}
.checkin-date{font-size:0.78rem;font-weight:600;color:var(--text-mid);}
.checkin-bar{background:var(--cream);border-radius:999px;height:8px;overflow:hidden;}
.checkin-bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,var(--terracotta-light),var(--terracotta));}
.checkin-amount{font-family:'Fraunces',serif;font-size:0.9rem;font-weight:800;color:var(--text-dark);}
.checkin-delta{font-size:0.72rem;font-weight:700;color:var(--sage);}
.add-checkin{background:var(--cream);border-radius:20px;padding:1.25rem;border:1.5px dashed rgba(90,138,106,0.3);}
.add-checkin-title{font-size:0.78rem;font-weight:700;color:var(--sage);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.75rem;}
.checkin-inputs{display:grid;grid-template-columns:1fr 1fr auto;gap:0.75rem;align-items:end;}
.btn-log{padding:0.65rem 1.25rem;background:linear-gradient(135deg,var(--sage),#3D6A50);color:white;border:none;border-radius:14px;font-family:'Fraunces',serif;font-size:0.88rem;font-weight:700;cursor:pointer;white-space:nowrap;transition:transform 0.15s,box-shadow 0.15s;}
.btn-log:hover{transform:translateY(-1px);box-shadow:0 4px 14px rgba(90,138,106,0.35);}

/* ── MILESTONES ── */
.milestones-row{display:flex;gap:0.75rem;flex-wrap:wrap;margin-top:1rem;}
.milestone-chip{display:flex;align-items:center;gap:0.5rem;padding:0.4rem 0.9rem;border-radius:999px;font-size:0.75rem;font-weight:700;}
.milestone-chip.earned{background:rgba(90,138,106,0.12);color:var(--sage);}
.milestone-chip.locked{background:var(--cream);color:var(--text-light);}

/* ── CONFETTI ── */
.confetti-overlay{position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden;}
.confetti-piece{position:absolute;top:-20px;width:10px;height:10px;border-radius:2px;animation:fall linear forwards;}
@keyframes fall{0%{transform:translateY(0) rotate(0deg);opacity:1;}100%{transform:translateY(110vh) rotate(720deg);opacity:0;}}
.celebration-banner{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,var(--sage),#3D6A50);color:white;padding:1rem 2rem;border-radius:20px;font-family:'Fraunces',serif;font-size:1rem;font-weight:700;box-shadow:var(--shadow-lg);z-index:10000;animation:bannerPop 0.4s cubic-bezier(0.34,1.56,0.64,1) both,bannerFade 0.4s ease 3.5s forwards;}
@keyframes bannerPop{from{opacity:0;transform:translateX(-50%) scale(0.8);}to{opacity:1;transform:translateX(-50%) scale(1);}}
@keyframes bannerFade{to{opacity:0;transform:translateX(-50%) translateY(-20px);}}

/* ── REFINANCING ── */
.refi-section{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.refi-intro{font-size:0.85rem;color:var(--text-mid);line-height:1.6;margin-bottom:1.5rem;padding:1rem 1.25rem;background:rgba(200,154,42,0.06);border:1.5px solid rgba(200,154,42,0.2);border-radius:16px;}
.refi-intro strong{color:var(--gold);}
.btn-refi{width:100%;padding:0.9rem;background:linear-gradient(135deg,var(--gold),#A8820A);color:white;border:none;border-radius:16px;font-family:'Fraunces',serif;font-size:1rem;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(200,154,42,0.35);transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.btn-refi:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 28px rgba(200,154,42,0.45);}
.btn-refi:disabled{opacity:0.6;cursor:not-allowed;}
.refi-comparison-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.5rem;}
.refi-current-card,.refi-new-card{border-radius:22px;padding:1.4rem;}
.refi-current-card{background:var(--cream);border:1.5px solid var(--border);}
.refi-new-card{background:linear-gradient(145deg,rgba(200,154,42,0.07),rgba(200,154,42,0.03));border:2px solid rgba(200,154,42,0.4);}
.refi-card-label{font-family:'Fraunces',serif;font-size:0.85rem;font-weight:700;color:var(--text-light);margin-bottom:0.8rem;text-transform:uppercase;letter-spacing:0.08em;}
.refi-card-stat{margin-bottom:0.6rem;}
.refi-card-stat-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-light);margin-bottom:0.1rem;}
.refi-card-stat-val{font-family:'Fraunces',serif;font-size:1.2rem;font-weight:800;color:var(--text-dark);}
.refi-card-stat-val.gold{color:var(--gold);}.refi-card-stat-val.green{color:var(--sage);}.refi-card-stat-val.red{color:#c0402a;}
.refi-lenders{display:flex;flex-direction:column;gap:0.75rem;margin-bottom:1.5rem;}
.lender-card{background:var(--cream);border-radius:18px;padding:1.1rem 1.4rem;display:flex;align-items:center;gap:1rem;transition:box-shadow 0.2s;}
.lender-card:hover{box-shadow:var(--shadow-sm);}
.lender-name{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);flex:1;}
.lender-rate{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:900;color:var(--gold);}
.lender-type{font-size:0.72rem;color:var(--text-light);margin-top:0.1rem;}
.lender-badge{background:rgba(90,138,106,0.12);color:var(--sage);font-size:0.68rem;font-weight:700;border-radius:999px;padding:0.18rem 0.6rem;text-transform:uppercase;letter-spacing:0.08em;}
.refi-savings-banner{background:linear-gradient(135deg,rgba(200,154,42,0.12),rgba(200,154,42,0.05));border:2px solid rgba(200,154,42,0.3);border-radius:20px;padding:1.25rem 1.5rem;display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;}
.rsb-label{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);}
.rsb-sub{font-size:0.78rem;color:var(--text-light);margin-top:0.2rem;}
.rsb-val{font-family:'Fraunces',serif;font-size:1.8rem;font-weight:900;color:var(--gold);}
.refi-warning{display:flex;gap:0.75rem;background:rgba(192,80,46,0.06);border:1.5px solid rgba(192,80,46,0.18);border-radius:16px;padding:0.9rem 1.2rem;font-size:0.82rem;color:var(--text-mid);line-height:1.5;}
.refi-warning-icon{font-size:1.1rem;flex-shrink:0;}

/* ── FEDERAL ── */
.fed-section{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.fed-intro{font-size:0.85rem;color:var(--text-mid);line-height:1.6;margin-bottom:1rem;padding:1rem 1.25rem;background:rgba(124,92,191,0.06);border:1.5px solid rgba(124,92,191,0.2);border-radius:16px;}
.fed-intro strong{color:var(--purple);}
.fed-inputs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;margin-bottom:1rem;}
.fed-field label{display:block;font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.4rem;}
.fed-field select{width:100%;background:var(--cream);border:1.5px solid transparent;border-radius:14px;padding:0.68rem 1rem;font-family:'Nunito',sans-serif;font-size:0.9rem;font-weight:500;color:var(--text-dark);outline:none;cursor:pointer;transition:border-color 0.2s;}
.fed-field select:focus{border-color:var(--purple-light);box-shadow:0 0 0 3px rgba(124,92,191,0.1);}
.btn-fed{width:100%;padding:0.9rem;background:linear-gradient(135deg,var(--purple),#5A3D9A);color:white;border:none;border-radius:16px;font-family:'Fraunces',serif;font-size:1rem;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(124,92,191,0.3);transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem;}
.btn-fed:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 28px rgba(124,92,191,0.4);}
.btn-fed:disabled{opacity:0.6;cursor:not-allowed;}
.fed-plans{display:flex;flex-direction:column;gap:0.85rem;margin-top:1.5rem;}
.fed-plan-card{border-radius:20px;padding:1.35rem 1.5rem;border:2px solid transparent;transition:transform 0.15s,box-shadow 0.15s;}
.fed-plan-card:hover{transform:translateY(-1px);box-shadow:var(--shadow-sm);}
.fed-plan-card.top-pick{border-color:var(--purple);background:linear-gradient(145deg,rgba(124,92,191,0.07),rgba(124,92,191,0.02));}
.fed-plan-card.good{background:rgba(90,138,106,0.05);border-color:rgba(90,138,106,0.2);}
.fed-plan-card.neutral{background:var(--cream);border-color:var(--border);}
.fed-plan-card.caution{background:rgba(217,108,69,0.04);border-color:rgba(217,108,69,0.18);}
.fed-plan-header{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:0.75rem;}
.fed-plan-name{font-family:'Fraunces',serif;font-size:1.05rem;font-weight:800;color:var(--text-dark);}
.fed-plan-badge{font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;padding:0.22rem 0.65rem;border-radius:999px;white-space:nowrap;}
.fed-plan-badge.purple{background:rgba(124,92,191,0.15);color:var(--purple);}
.fed-plan-badge.green{background:rgba(90,138,106,0.15);color:var(--sage);}
.fed-plan-badge.gray{background:rgba(160,150,140,0.15);color:var(--text-mid);}
.fed-plan-badge.orange{background:rgba(217,108,69,0.12);color:var(--terracotta);}
.fed-plan-stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:0.75rem;margin-bottom:0.75rem;}
.fed-plan-stat-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.15rem;}
.fed-plan-stat-val{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:800;color:var(--text-dark);}
.fed-plan-stat-val.purple{color:var(--purple);}.fed-plan-stat-val.green{color:var(--sage);}.fed-plan-stat-val.red{color:#c0402a;}
.fed-plan-desc{font-size:0.81rem;color:var(--text-mid);line-height:1.55;}
.fed-plan-pros-cons{display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;margin-top:0.75rem;}
.fed-pc-item{font-size:0.77rem;color:var(--text-mid);display:flex;gap:0.4rem;line-height:1.4;}
.fed-pc-item.pro::before{content:'✓';color:var(--sage);font-weight:700;flex-shrink:0;}
.fed-pc-item.con::before{content:'✗';color:var(--terracotta);font-weight:700;flex-shrink:0;}
.fed-disclaimer{font-size:0.78rem;color:var(--text-light);line-height:1.55;padding:0.85rem 1.1rem;background:var(--cream);border-radius:14px;margin-top:1rem;}

/* ── FORGIVENESS CHECKER ── */
.forgive-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.forgive-intro{font-size:0.85rem;color:var(--text-mid);line-height:1.6;margin-bottom:1.25rem;padding:1rem 1.25rem;background:rgba(90,138,106,0.06);border:1.5px solid rgba(90,138,106,0.2);border-radius:16px;}
.forgive-intro strong{color:var(--sage);}
.forgive-inputs{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem;}
.forgive-field label{display:block;font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.4rem;}
.forgive-field select,.forgive-field input[type="text"]{width:100%;background:var(--cream);border:1.5px solid transparent;border-radius:14px;padding:0.68rem 1rem;font-family:'Nunito',sans-serif;font-size:0.9rem;font-weight:500;color:var(--text-dark);outline:none;cursor:pointer;transition:border-color 0.2s;}
.forgive-field select:focus,.forgive-field input[type="text"]:focus{border-color:var(--sage-light);box-shadow:0 0 0 3px rgba(90,138,106,0.1);}
.btn-forgive{width:100%;padding:0.9rem;background:linear-gradient(135deg,var(--sage),#3D6A50);color:white;border:none;border-radius:16px;font-family:'Fraunces',serif;font-size:1rem;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(90,138,106,0.3);transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem;}
.btn-forgive:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 28px rgba(90,138,106,0.4);}
.btn-forgive:disabled{opacity:0.6;cursor:not-allowed;}
.spinner.sage{border-color:rgba(90,138,106,0.15);border-top-color:var(--sage);}
.forgive-programs{display:flex;flex-direction:column;gap:0.85rem;margin-top:1.5rem;}
.forgive-program-card{border-radius:20px;padding:1.25rem 1.5rem;border:2px solid transparent;}
.forgive-program-card.eligible{background:linear-gradient(145deg,rgba(90,138,106,0.08),rgba(90,138,106,0.02));border-color:rgba(90,138,106,0.3);}
.forgive-program-card.maybe{background:linear-gradient(145deg,rgba(200,154,42,0.07),rgba(200,154,42,0.02));border-color:rgba(200,154,42,0.25);}
.forgive-program-card.unlikely{background:var(--cream);border-color:var(--border);}
.fp-header{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:0.6rem;}
.fp-name{font-family:'Fraunces',serif;font-size:1rem;font-weight:800;color:var(--text-dark);}
.fp-badge{font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;padding:0.22rem 0.65rem;border-radius:999px;white-space:nowrap;}
.fp-badge.green{background:rgba(90,138,106,0.15);color:var(--sage);}
.fp-badge.gold{background:rgba(200,154,42,0.15);color:var(--gold);}
.fp-badge.gray{background:rgba(160,150,140,0.15);color:var(--text-mid);}
.fp-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:0.6rem;margin-bottom:0.6rem;}
.fp-stat-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.15rem;}
.fp-stat-val{font-family:'Fraunces',serif;font-size:1rem;font-weight:800;color:var(--text-dark);}
.fp-stat-val.green{color:var(--sage);}.fp-stat-val.gold{color:var(--gold);}
.fp-desc{font-size:0.81rem;color:var(--text-mid);line-height:1.55;}
.fp-action{display:inline-flex;align-items:center;gap:0.3rem;margin-top:0.6rem;font-size:0.76rem;font-weight:700;color:var(--sage);text-decoration:none;background:rgba(90,138,106,0.1);border-radius:999px;padding:0.2rem 0.75rem;}

/* ── SALARY ROI ── */
.salary-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.salary-sliders{display:flex;flex-direction:column;gap:1.5rem;margin-bottom:1.75rem;}
.salary-impact-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:0.85rem;}
.salary-tile{background:var(--cream);border-radius:18px;padding:1rem 1.1rem;}
.salary-tile-label{font-size:0.63rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.25rem;}
.salary-tile-val{font-family:'Fraunces',serif;font-size:1.25rem;font-weight:900;color:var(--text-dark);}
.salary-tile-val.green{color:var(--sage);}
.salary-tile-delta{font-size:0.7rem;font-weight:700;color:var(--sage);margin-top:0.15rem;}

/* ── PARTNER MODE ── */
.partner-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.partner-toggle-row{display:flex;gap:0.75rem;margin-bottom:1.5rem;}
.partner-toggle{padding:0.5rem 1.25rem;border-radius:999px;border:2px solid var(--border);background:var(--cream);font-size:0.82rem;font-weight:700;cursor:pointer;transition:all 0.2s;color:var(--text-mid);}
.partner-toggle.active{border-color:var(--pink);background:rgba(192,90,138,0.1);color:var(--pink);}
.partner-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.25rem;}
.partner-col-title{font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:var(--text-dark);margin-bottom:0.85rem;padding-bottom:0.6rem;border-bottom:2px solid var(--border);}
.partner-col-title.you{color:var(--terracotta);}
.partner-col-title.them{color:var(--pink);}
.partner-mini-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;margin-bottom:0.5rem;}
.partner-result-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;padding-top:1.25rem;border-top:1.5px dashed var(--border);}
.partner-res-tile{background:var(--cream);border-radius:18px;padding:1rem 1.25rem;}
.partner-res-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.07em;color:var(--text-light);margin-bottom:0.25rem;}
.partner-res-val{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:900;color:var(--text-dark);}
.partner-res-val.green{color:var(--sage);}

/* ── INTEREST CALENDAR ── */
.calendar-card{background:var(--warm-white);border-radius:28px;box-shadow:var(--shadow-md);border:1px solid rgba(255,255,255,0.8);padding:2rem;margin-bottom:1.5rem;}
.calendar-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:0.6rem;margin-bottom:1.25rem;}
.cal-month{background:var(--cream);border-radius:14px;padding:0.75rem 0.65rem;text-align:center;}
.cal-month-name{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-light);margin-bottom:0.35rem;}
.cal-month-interest{font-family:'Fraunces',serif;font-size:0.95rem;font-weight:900;color:var(--terracotta);}
.cal-month-bar{height:4px;border-radius:999px;background:linear-gradient(90deg,var(--terracotta-light),var(--terracotta));margin-top:0.35rem;transition:width 0.4s;}
.cal-total-row{display:flex;justify-content:space-between;align-items:center;padding:1rem 1.25rem;background:rgba(217,108,69,0.06);border:1.5px solid rgba(217,108,69,0.18);border-radius:16px;margin-bottom:0.75rem;}
.cal-total-label{font-family:'Fraunces',serif;font-size:0.95rem;font-weight:700;color:var(--text-dark);}
.cal-total-val{font-family:'Fraunces',serif;font-size:1.5rem;font-weight:900;color:var(--terracotta);}
.cal-breakdown{display:flex;flex-direction:column;gap:0.45rem;}
.cal-loan-row{display:flex;align-items:center;gap:0.75rem;font-size:0.81rem;}
.cal-loan-name{flex:1;color:var(--text-mid);}
.cal-loan-bar-wrap{flex:2;background:var(--cream);border-radius:999px;height:7px;overflow:hidden;}
.cal-loan-bar-fill{height:100%;border-radius:999px;}
.cal-loan-amount{font-weight:700;color:var(--text-dark);min-width:60px;text-align:right;}

/* ── BOTTOM NAV (mobile only) ── */
.bottom-nav{display:none;}

/* ── SECTION ANCHORS ── */
.section-anchor{scroll-margin-top:1rem;}

/* ════════════════════════════════════════
   TABLET  ≤ 820px
════════════════════════════════════════ */
@media(max-width:820px){
  .inner{padding:0 1rem 5rem;}
  .summary-row{grid-template-columns:1fr 1fr;}
  .strategies-grid{grid-template-columns:1fr 1fr;}
  .h2h-grid{grid-template-columns:1fr;gap:0.75rem;}
  .h2h-vs{display:none;}
  .salary-impact-grid{grid-template-columns:1fr 1fr;}
  .partner-result-grid{grid-template-columns:1fr 1fr;}
  .amort-summary-row{grid-template-columns:1fr 1fr;}
  .calendar-grid{grid-template-columns:repeat(4,1fr);}
  .fed-plan-stats-row{grid-template-columns:1fr 1fr;}
  .fp-stats{grid-template-columns:1fr 1fr;}
}

/* ════════════════════════════════════════
   MOBILE  ≤ 540px  — true mobile-first
════════════════════════════════════════ */
@media(max-width:540px){
  /* Layout */
  html{-webkit-text-size-adjust:100%;}
  .inner{padding:0 0.85rem 6rem;}
  .card,.refi-section,.fed-section,.forgive-card,.hustle-card,.tax-card,.progress-card,.partner-card,.salary-card,.payoff-order-card,.amort-card,.calendar-card,.whatif-card{border-radius:20px;padding:1.35rem;}

  /* Header */
  .header{padding:2rem 0 1.25rem;}
  h1{font-size:2.1rem;letter-spacing:-0.01em;}
  .header-sub{font-size:0.92rem;}

  /* Toolbar — move to bottom-left so it doesn't clash with content */
  .toolbar{top:auto;bottom:5rem;right:0.85rem;flex-direction:column;}

  /* Bottom nav */
  .bottom-nav{
    display:flex;position:fixed;bottom:0;left:0;right:0;
    background:var(--warm-white);border-top:1.5px solid var(--border);
    padding:0.4rem 0 calc(0.4rem + env(safe-area-inset-bottom));
    z-index:90;justify-content:space-around;
    box-shadow:0 -4px 20px rgba(180,100,60,0.1);
  }
  .bnav-item{display:flex;flex-direction:column;align-items:center;gap:0.15rem;padding:0.3rem 0.6rem;border-radius:12px;border:none;background:none;cursor:pointer;color:var(--text-light);font-family:'Nunito',sans-serif;font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;transition:color 0.15s;}
  .bnav-item:active{transform:scale(0.93);}
  .bnav-icon{font-size:1.25rem;line-height:1;}
  .bnav-item.active{color:var(--terracotta);}

  /* Touch-friendly inputs — 44px min height (Apple HIG) */
  input[type="text"],input[type="number"],input[type="date"]{padding:0.75rem 0.9rem;font-size:1rem;border-radius:12px;min-height:44px;}
  .fed-field select,.forgive-field select{padding:0.75rem 0.9rem;font-size:1rem;min-height:44px;border-radius:12px;}
  .btn-cta{padding:1.1rem;font-size:1rem;border-radius:16px;min-height:52px;}
  .btn-parse,.btn-refi,.btn-fed,.btn-forgive,.btn-log{min-height:48px;}
  .btn-sm{padding:0.6rem 1.1rem;font-size:0.82rem;}
  .btn-add{padding:0.65rem 1.1rem;min-height:44px;}
  .btn-remove{width:38px;height:38px;}
  .toolbar-btn{width:44px;height:44px;font-size:1.1rem;}

  /* Loan form — stack to 2 cols */
  .col-heads{display:none;}
  .loans-list{gap:1rem;}
  .loan-row{grid-template-columns:1fr 1fr;grid-template-rows:auto auto;gap:0.5rem;}
  .loan-row>input:first-child{grid-column:1/-1;}
  .loan-row .btn-remove{grid-column:2;grid-row:2;justify-self:end;align-self:center;}

  /* Budget */
  .manual-budget-row{grid-template-columns:1fr;}
  .budget-row-grid{grid-template-columns:1fr;}

  /* Summary tiles — 2 col */
  .summary-row{grid-template-columns:1fr 1fr;gap:0.65rem;}
  .tile-value{font-size:1.4rem;}
  .summary-tile{padding:1rem;}

  /* H2H */
  .h2h-card{padding:1.35rem;}
  .h2h-grid{grid-template-columns:1fr;}
  .h2h-vs{display:none;}
  .h2h-stat-val{font-size:1.1rem;}

  /* Strategies */
  .strategies-grid{grid-template-columns:1fr;}
  .strat-card{padding:1.1rem;}

  /* What-if */
  .whatif-results-grid{grid-template-columns:1fr 1fr;}
  .whatif-card{padding:1.35rem;}
  .whatif-tile-val{font-size:1.2rem;}

  /* Hustle */
  .hustle-options{grid-template-columns:1fr 1fr;}
  .hustle-impact-grid{grid-template-columns:1fr;}
  .hustle-stat-val{font-size:1.1rem;}

  /* Tax */
  .tax-breakdown{grid-template-columns:1fr 1fr;}
  .tax-bracket-row{gap:0.4rem;}
  .tax-bracket-btn{padding:0.45rem 0.7rem;font-size:0.74rem;}

  /* Progress */
  .checkin-row{grid-template-columns:90px 1fr auto;}
  .checkin-delta{display:none;}
  .checkin-inputs{grid-template-columns:1fr 1fr;grid-template-rows:auto auto;}
  .checkin-inputs .btn-log{grid-column:1/-1;}
  .milestones-row{gap:0.5rem;}
  .milestone-chip{font-size:0.68rem;padding:0.3rem 0.65rem;}

  /* Calendar */
  .calendar-grid{grid-template-columns:repeat(3,1fr);gap:0.45rem;}
  .cal-month{padding:0.6rem 0.45rem;}
  .cal-month-interest{font-size:0.82rem;}
  .cal-month-name{font-size:0.58rem;}

  /* Refi */
  .refi-comparison-grid{grid-template-columns:1fr;}
  .refi-savings-banner{flex-direction:column;gap:0.5rem;text-align:center;}
  .rsb-val{font-size:1.5rem;}
  .lender-card{padding:0.9rem 1rem;}

  /* Federal */
  .fed-inputs{grid-template-columns:1fr;}
  .fed-plan-stats-row{grid-template-columns:1fr 1fr;}
  .fed-plan-pros-cons{grid-template-columns:1fr;}
  .fed-plan-card{padding:1rem 1.1rem;}

  /* Forgiveness */
  .forgive-inputs{grid-template-columns:1fr;}
  .fp-stats{grid-template-columns:1fr 1fr;}

  /* Salary ROI */
  .salary-impact-grid{grid-template-columns:1fr 1fr;}

  /* Partner */
  .partner-grid{grid-template-columns:1fr;}
  .partner-mini-row{grid-template-columns:1fr 1fr;}
  .partner-result-grid{grid-template-columns:1fr;}

  /* Payoff roadmap */
  .payoff-step{grid-template-columns:38px 1fr;gap:0.6rem;}
  .payoff-step-num{width:30px;height:30px;font-size:0.78rem;}
  .payoff-step-body{padding:0.85rem 1rem;}
  .payoff-step-stats{gap:0.75rem;}

  /* Amortization */
  .amort-summary-row{grid-template-columns:1fr 1fr;}
  .amort-tabs{gap:0.4rem;}
  .amort-tab{padding:0.35rem 0.8rem;font-size:0.75rem;}
  table{font-size:0.75rem;}
  th,td{padding:0.5rem 0.65rem;}
  .amort-pagination{flex-direction:column;gap:0.5rem;align-items:center;}

  /* Section labels */
  .section-label{font-size:1.05rem;}

  /* Charts — reduce height on mobile */

  /* CSV */
  .csv-cats{grid-template-columns:1fr;}

  /* Tip items */
  .tip-item{padding:0.75rem 1rem;}
  .tips-grid{gap:0.55rem;}
}

/* ════════ DARK MODE bottom nav ════════ */
[data-dark] .bottom-nav{background:var(--warm-white);border-color:var(--border);}
`;

const fmt = n => "$" + Math.round(n).toLocaleString();
const fmtYM = m => { const y = Math.floor(m/12), mo = m%12; return y > 0 ? `${y}y ${mo}m` : `${mo}m`; };

function calcMethod(loans, extra = 0, method = "avalanche") {
  let bl = loans.map(l => ({ ...l, b: parseFloat(l.balance) || 0 }));
  let month = 0, interest = 0, data = [];
  while (bl.some(l => l.b > 0.01) && month < 600) {
    month++;
    let ex = extra;
    for (const l of bl) {
      if (l.b <= 0) continue;
      const r = (parseFloat(l.rate)||0)/100/12;
      interest += l.b * r; l.b += l.b * r;
      l.b -= Math.min(parseFloat(l.minPayment)||0, l.b);
      if (l.b < 0) l.b = 0;
    }
    const sorted = method === "avalanche"
      ? [...bl].sort((a,b) => (parseFloat(b.rate)||0)-(parseFloat(a.rate)||0))
      : [...bl].sort((a,b) => a.b - b.b);
    for (const l of sorted) {
      if (l.b <= 0 || ex <= 0) continue;
      const pay = Math.min(ex, l.b); l.b -= pay; ex -= pay;
    }
    const total = bl.reduce((s,l) => s+Math.max(l.b,0), 0);
    if (month % 2 === 0 || month <= 12) data.push({ month, balance: Math.round(total) });
  }
  return { months: month, interest, data };
}

function fileToBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result.split(",")[1]);
    r.onerror = () => rej(new Error("Read failed"));
    r.readAsDataURL(file);
  });
}
function getMediaType(f) { return f.type === "application/pdf" ? "application/pdf" : f.type.startsWith("image/") ? f.type : null; }
function getFileIcon(f) { return f.type === "application/pdf" ? "📄" : f.type.startsWith("image/") ? "🖼️" : "📎"; }

const CTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return <div className="ct"><div className="ct-label">Month {label}</div>{payload.map(p=><div key={p.name} style={{color:p.color,fontWeight:700}}>{p.name}: {fmt(p.value)}</div>)}</div>;
};

// Confetti component
function Confetti({ show }) {
  if (!show) return null;
  const colors = ["#D96C45","#5A8A6A","#5B7FA6","#C89A2A","#7C5CBF","#F0A882","#8ABD98"];
  const pieces = Array.from({length: 60}, (_, i) => ({
    id: i, color: colors[i % colors.length],
    left: Math.random() * 100, delay: Math.random() * 0.8,
    duration: 1.5 + Math.random() * 1.5, size: 6 + Math.random() * 8
  }));
  return (
    <div className="confetti-overlay">
      {pieces.map(p => (
        <div key={p.id} className="confetti-piece" style={{
          left: `${p.left}%`, background: p.color,
          width: p.size, height: p.size, borderRadius: Math.random() > 0.5 ? "50%" : "2px",
          animationDuration: `${p.duration}s`, animationDelay: `${p.delay}s`
        }}/>
      ))}
    </div>
  );
}

const HUSTLE_OPTIONS = [
  { id:"freelance", icon:"💻", label:"Freelancing", range:[500,2000], default:750 },
  { id:"rideshare", icon:"🚗", label:"Rideshare", range:[200,800], default:400 },
  { id:"tutoring", icon:"📚", label:"Tutoring", range:[200,600], default:350 },
  { id:"delivery", icon:"📦", label:"Delivery", range:[300,700], default:450 },
  { id:"selling", icon:"🛍️", label:"Selling Online", range:[100,500], default:250 },
  { id:"other", icon:"✨", label:"Other Income", range:[100,1000], default:300 },
];

const TAX_BRACKETS = [
  { label:"10%", rate:0.10 }, { label:"12%", rate:0.12 }, { label:"22%", rate:0.22 },
  { label:"24%", rate:0.24 }, { label:"32%", rate:0.32 }, { label:"35%", rate:0.35 },
];

const MILESTONE_DEFS = [
  { id:"start", icon:"🎯", label:"Plan Created", pct:0 },
  { id:"10pct", icon:"🌱", label:"10% Paid Off", pct:10 },
  { id:"25pct", icon:"🔥", label:"Quarter Done", pct:25 },
  { id:"50pct", icon:"🏅", label:"Halfway There!", pct:50 },
  { id:"75pct", icon:"🚀", label:"75% Done!", pct:75 },
  { id:"done", icon:"🎉", label:"Debt Free!", pct:100 },
];

let idCtr = 3;

export default function App() {
  const [loans, setLoans] = useState([
    { id: 1, name: "Federal Sub", balance: "28000", rate: "5.5", minPayment: "280" },
    { id: 2, name: "Private Loan", balance: "15000", rate: "8.9", minPayment: "200" },
  ]);
  const [income, setIncome] = useState("5200");
  const [extra, setExtra] = useState("300");
  const [done, setDone] = useState(false);

  // Doc uploads
  const [loanFiles, setLoanFiles] = useState([]);
  const [loanParseStatus, setLoanParseStatus] = useState("idle");
  const [loanParseMsg, setLoanParseMsg] = useState("");
  const [newLoanIds, setNewLoanIds] = useState(new Set());
  const [loanDrag, setLoanDrag] = useState(false);
  const [budgetFiles, setBudgetFiles] = useState([]);
  const [budgetParseStatus, setBudgetParseStatus] = useState("idle");
  const [budgetParseMsg, setBudgetParseMsg] = useState("");
  const [budgetData, setBudgetData] = useState(null);
  const [budgetDrag, setBudgetDrag] = useState(false);

  // Refinancing & federal
  const [refiStatus, setRefiStatus] = useState("idle");
  const [refiData, setRefiData] = useState(null);
  const [fedStatus, setFedStatus] = useState("idle");
  const [fedData, setFedData] = useState(null);
  const [fedLoansType, setFedLoansType] = useState("mix");
  const [fedFamilySize, setFedFamilySize] = useState("1");
  const [fedFilingStatus, setFedFilingStatus] = useState("single");

  // What-if simulator
  const [whatIfExtra, setWhatIfExtra] = useState(0);
  const [whatIfHustle, setWhatIfHustle] = useState(0);

  // Side hustle
  const [selectedHustle, setSelectedHustle] = useState(null);
  const [hustleAmount, setHustleAmount] = useState(400);

  // Tax deduction
  const [taxBracket, setTaxBracket] = useState(0.22);

  // Forgiveness checker
  const [forgiveStatus, setForgiveStatus] = useState("idle");
  const [forgiveData, setForgiveData] = useState(null);
  const [forgiveEmployer, setForgiveEmployer] = useState("government");
  const [forgiveJobTitle, setForgiveJobTitle] = useState("");
  const [forgiveYears, setForgiveYears] = useState("2");

  // Salary ROI
  const [salaryRaise, setSalaryRaise] = useState(5000);
  const [salaryApplyPct, setSalaryApplyPct] = useState(50);

  // Partner mode
  const [partnerActive, setPartnerActive] = useState(false);
  const [partnerLoans, setPartnerLoans] = useState([{ id: 100, name:"Partner Loan 1", balance:"12000", rate:"6.5", minPayment:"130" }]);
  const [partnerIncome, setPartnerIncome] = useState("4000");

  // Interest calendar - year offset
  const [calYear, setCalYear] = useState(0);

  // Dark mode
  const [darkMode, setDarkMode] = useState(false);
  // Share toast
  const [shareToast, setShareToast] = useState(false);
  // CSV import
  const [csvDrag, setCsvDrag] = useState(false);
  const [csvResult, setCsvResult] = useState(null);
  // Amortization
  const [amortLoanIdx, setAmortLoanIdx] = useState(0);
  const [amortPage, setAmortPage] = useState(0);
  const AMORT_PAGE_SIZE = 24;
  // Bottom nav active section
  const [activeSection, setActiveSection] = useState("setup");

  // ── URL ENCODE/DECODE ──
  useEffect(() => {
    try {
      const hash = window.location.hash.slice(1);
      if (!hash) return;
      const state = JSON.parse(atob(hash));
      if (state.loans?.length) { setLoans(state.loans.map((l,i)=>({...l,id:i+1}))); idCtr=state.loans.length+2; }
      if (state.income) setIncome(state.income);
      if (state.extra) setExtra(state.extra);
    } catch {}
  }, []);

  const shareURL = () => {
    const valid = loans.filter(l=>parseFloat(l.balance)>0);
    const payload = btoa(JSON.stringify({ loans: valid, income, extra }));
    const url = window.location.href.split('#')[0] + '#' + payload;
    try { navigator.clipboard.writeText(url); } catch { window.prompt("Copy this link:", url); }
    setShareToast(true);
    setTimeout(()=>setShareToast(false), 2800);
  };

  // ── DARK MODE effect ──
  useEffect(() => {
    const root = document.getElementById('app-root');
    if (root) { darkMode ? root.setAttribute('data-dark','') : root.removeAttribute('data-dark'); }
  }, [darkMode]);

  // ── SCROLL TRACKING for bottom nav ──
  useEffect(() => {
    const sections = ['setup','results','tools','ai','progress'];
    const onScroll = () => {
      for (const id of [...sections].reverse()) {
        const el = document.getElementById('sec-'+id);
        if (el && el.getBoundingClientRect().top <= 120) { setActiveSection(id); return; }
      }
      setActiveSection('setup');
    };
    window.addEventListener('scroll', onScroll, { passive:true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // ── CSV BANK IMPORT ──
  const parseCSV = (text) => {
    const lines = text.trim().split('\n').filter(l=>l.trim());
    if (lines.length < 2) return null;
    const header = lines[0].split(',').map(h=>h.trim().replace(/"/g,'').toLowerCase());
    const descIdx = header.findIndex(h=>['description','memo','payee','name','transaction'].some(k=>h.includes(k)));
    const amtIdx  = header.findIndex(h=>['amount','debit','credit','transaction amount'].some(k=>h.includes(k)));
    const dateIdx = header.findIndex(h=>h.includes('date'));
    if (amtIdx === -1) return null;
    const INCOME_KEYS = ['payroll','direct dep','salary','income','transfer in','venmo credit','zelle credit','deposit','refund','reimburs'];
    const CATS = {
      'Housing':['rent','mortgage','hoa','lease'],
      'Food':['restaurant','food','grocery','doordash','uber eats','grubhub','starbucks','coffee','pizza','sushi','taco','chipotle'],
      'Transport':['uber','lyft','gas','parking','transit','mta','bart','metro','toll','auto','car'],
      'Utilities':['electric','water','internet','phone','verizon','at&t','tmobile','comcast','spectrum','utility','pg&e'],
      'Subscriptions':['netflix','spotify','hulu','disney','amazon prime','apple','google','subscription','membership'],
      'Health':['pharmacy','cvs','walgreens','doctor','dentist','insurance','gym','fitness'],
      'Shopping':['amazon','walmart','target','costco','clothing','shoes','apparel'],
      'Other Spending':[]
    };
    let totalIncome = 0, totalSpending = 0;
    const catTotals = {};
    Object.keys(CATS).forEach(c=>catTotals[c]=0);
    lines.slice(1).forEach(line=>{
      const cols = line.match(/(".*?"|[^,]+|(?<=,)(?=,)|^(?=,)|(?<=,)$)/g)?.map(c=>c.trim().replace(/^"|"$/g,''))||line.split(',').map(c=>c.trim());
      const raw = parseFloat((cols[amtIdx]||'0').replace(/[$,()]/g,''));
      if (isNaN(raw)||raw===0) return;
      const amt = Math.abs(raw);
      const desc = (cols[descIdx]||'').toLowerCase();
      const isIncome = raw > 0 ? true : INCOME_KEYS.some(k=>desc.includes(k));
      if (isIncome) { totalIncome += amt; return; }
      totalSpending += amt;
      let matched = false;
      for (const [cat, keys] of Object.entries(CATS)) {
        if (keys.some(k=>desc.includes(k))) { catTotals[cat]+=amt; matched=true; break; }
      }
      if (!matched) catTotals['Other Spending']+=amt;
    });
    const categories = Object.entries(catTotals).filter(([,v])=>v>0).map(([name,amount])=>({name,amount:Math.round(amount)})).sort((a,b)=>b.amount-a.amount);
    const surplus = Math.round(totalIncome - totalSpending);
    return { totalIncome:Math.round(totalIncome), totalSpending:Math.round(totalSpending), categories, surplus };
  };

  const handleCSVFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = parseCSV(e.target.result);
      if (!result) { setCsvResult({error:"Couldn't parse this CSV. Make sure it has Amount and Description columns."}); return; }
      setCsvResult(result);
      if (result.totalIncome > 0) setIncome(String(result.totalIncome));
      if (result.surplus > 0) setExtra(String(Math.max(0, result.surplus - (parseFloat(extra)||0) > 0 ? result.surplus : parseFloat(extra)||0)));
    };
    reader.readAsText(file);
  };

  // Progress tracker (persisted)
  const [checkIns, setCheckIns] = useState([]);
  const [checkInDate, setCheckInDate] = useState(() => new Date().toISOString().slice(0,10));
  const [checkInBalance, setCheckInBalance] = useState("");
  const [storageLoaded, setStorageLoaded] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [celebrationMsg, setCelebrationMsg] = useState("");
  const prevPctRef = useRef(0);

  // Load saved check-ins from storage
  useEffect(() => {
    async function load() {
      try {
        const result = await new Promise(r => r({value: localStorage.getItem("checkins")}));
        if (result?.value) setCheckIns(JSON.parse(result.value));
      } catch {}
      setStorageLoaded(true);
    }
    load();
  }, []);

  const saveCheckIns = async (data) => {
    try { await new Promise(r => { localStorage.setItem("checkins", JSON.stringify(data)); r(true); }); } catch {}
  };

  const addCheckIn = async () => {
    if (!checkInBalance || !checkInDate) return;
    const bal = parseFloat(checkInBalance);
    if (isNaN(bal)) return;
    const newEntry = { date: checkInDate, balance: bal, ts: Date.now() };
    const updated = [...checkIns, newEntry].sort((a,b) => new Date(a.date) - new Date(b.date));
    setCheckIns(updated);
    await saveCheckIns(updated);
    setCheckInBalance("");
    // Check milestones
    const totalDebt = loans.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    if (totalDebt > 0) {
      const paidPct = Math.round(((totalDebt - bal) / totalDebt) * 100);
      const prevPct = prevPctRef.current;
      const crossed = MILESTONE_DEFS.find(m => m.pct > 0 && prevPct < m.pct && paidPct >= m.pct);
      if (crossed) { triggerCelebration(`${crossed.icon} ${crossed.label}`); }
      prevPctRef.current = paidPct;
    }
  };

  const triggerCelebration = (msg) => {
    setCelebrationMsg(msg);
    setShowConfetti(true);
    setTimeout(() => { setShowConfetti(false); setCelebrationMsg(""); }, 4000);
  };

  const addLoan = () => { const id = idCtr++; setLoans(l => [...l, { id, name:"", balance:"", rate:"", minPayment:"" }]); };
  const remove = id => setLoans(l => l.filter(x => x.id !== id));
  const update = (id, f, v) => setLoans(l => l.map(x => x.id === id ? {...x, [f]: v} : x));

  const handleFiles = useCallback((files, setF) => {
    const valid = Array.from(files).filter(f => getMediaType(f));
    if (!valid.length) return;
    setF(prev => { const ex = new Set(prev.map(f=>f.name)); return [...prev, ...valid.filter(f=>!ex.has(f.name))]; });
  }, []);

  const parseDoc = async (files, setStatus, setMsg, onSuccess) => {
    setStatus("parsing");
    try {
      const parts = [];
      for (const f of files) {
        const mt = getMediaType(f), b64 = await fileToBase64(f);
        parts.push(mt === "application/pdf" ? { type:"document", source:{ type:"base64", media_type:"application/pdf", data:b64 } } : { type:"image", source:{ type:"base64", media_type:mt, data:b64 } });
      }
      parts.push({ type:"text", text: onSuccess.prompt });
      const res = await fetch("/api/anthropic", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:1000, messages:[{ role:"user", content:parts }] }) });
      const data = await res.json();
      const parsed = JSON.parse((data.content?.find(b=>b.type==="text")?.text||"").replace(/```json|```/g,"").trim());
      onSuccess.fn(parsed);
      setStatus("success"); setMsg(parsed.notes || "Done!");
    } catch(e) { setStatus("error"); setMsg(e.message||"Parse failed."); }
  };

  const parseLoanDocs = () => parseDoc(loanFiles, setLoanParseStatus, setLoanParseMsg, {
    prompt: `Extract all student loan details. Return ONLY JSON: {"loans":[{"name":"","balance":"","rate":"","minPayment":""}],"notes":"summary"} If none: {"loans":[],"notes":"No loans found."}`,
    fn: (parsed) => {
      if (!parsed.loans?.length) { setLoanParseStatus("error"); setLoanParseMsg("No loans found."); return; }
      const newIds = new Set();
      const newLoans = parsed.loans.map(l => { const id = idCtr++; newIds.add(id); return { id, name:l.name||"", balance:l.balance||"", rate:l.rate||"", minPayment:l.minPayment||"" }; });
      setLoans(prev => [...prev.filter(l => parseFloat(l.balance)>0||l.name.trim()), ...newLoans]);
      setNewLoanIds(newIds); setTimeout(()=>setNewLoanIds(new Set()), 3000);
    }
  });

  const parseBudgetDoc = () => parseDoc(budgetFiles, setBudgetParseStatus, setBudgetParseMsg, {
    prompt: `Analyze this budget/bank statement. Return ONLY JSON: {"monthlyIncome":"number","expenses":[{"name":"","amount":""}],"totalExpenses":"number","availableSurplus":"number","notes":"1 sentence"} Exclude loan/debt payments.`,
    fn: (parsed) => {
      setBudgetData(parsed);
      if (parseFloat(parsed.monthlyIncome)>0) setIncome(String(Math.round(parseFloat(parsed.monthlyIncome))));
      if (parseFloat(parsed.availableSurplus)>0) setExtra(String(Math.round(parseFloat(parsed.availableSurplus))));
    }
  });

  const searchRefinancing = async () => {
    setRefiStatus("searching");
    const totalDebt = loans.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    const avgRate = loans.filter(l=>parseFloat(l.balance)>0).reduce((s,l)=>s+(parseFloat(l.rate)||0),0)/Math.max(1,loans.filter(l=>parseFloat(l.balance)>0).length);
    try {
      const res = await fetch("/api/anthropic", { method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:2000, tools:[{type:"web_search_20250305",name:"web_search"}],
          messages:[{ role:"user", content:`Search for current 2025 student loan refinancing rates from SoFi, Earnest, Laurel Road, ELFI, Splash Financial. My balance: $${Math.round(totalDebt).toLocaleString()}, avg rate: ${avgRate.toFixed(2)}%, income: $${parseFloat(income).toLocaleString()}/mo. Return ONLY JSON: {"currentAvgRate":"${avgRate.toFixed(2)}","bestRefiRate":"","typicalRefiRate":"","lenders":[{"name":"","rateRange":"","fixedOrVariable":"","highlight":"","url":""}],"monthlySavings":"","totalSavings":"","newPayoffMonths":"","recommendation":"","refinanceWarnings":[]}` }]
        })
      });
      const data = await res.json();
      const textBlock = data.content?.find(b=>b.type==="text");
      setRefiData(JSON.parse(textBlock.text.replace(/```json|```/g,"").trim()));
      setRefiStatus("done");
    } catch { setRefiStatus("error"); }
  };

  const analyzeFederalPlans = async () => {
    setFedStatus("searching");
    const totalBal = loans.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    const annualIncome = (parseFloat(income)||0)*12;
    try {
      const res = await fetch("/api/anthropic", { method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:2500, tools:[{type:"web_search_20250305",name:"web_search"}],
          messages:[{ role:"user", content:`Search current 2025 federal student loan repayment plans (SAVE, IBR, PAYE, ICR, Standard, Graduated) rules and any court updates. My profile: annual income $${Math.round(annualIncome).toLocaleString()}, family size ${fedFamilySize}, filing ${fedFilingStatus}, loan type ${fedLoansType}, balance $${Math.round(totalBal).toLocaleString()}, extra budget $${parseFloat(extra)||0}/mo. Return ONLY JSON: {"plans":[{"name":"","shortName":"","emoji":"","tier":"top-pick|good|neutral|caution","badge":"","estimatedMonthlyPayment":"","estimatedPayoffMonths":"","estimatedTotalPaid":"","forgivenessPotential":"","description":"","pros":[],"cons":[]}],"topPickName":"","topPickReason":"","pslfEligible":false,"pslfNote":"","importantNote":""}` }]
        })
      });
      const data = await res.json();
      const textBlock = data.content?.find(b=>b.type==="text");
      setFedData(JSON.parse(textBlock.text.replace(/```json|```/g,"").trim()));
      setFedStatus("done");
    } catch { setFedStatus("error"); }
  };

  const results = useMemo(() => {
    if (!done) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    if (!valid.length) return null;
    const totalDebt = valid.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    const totalMin = valid.reduce((s,l)=>s+(parseFloat(l.minPayment)||0),0);
    const ex = parseFloat(extra)||0;
    const inc = parseFloat(income)||1;
    const minOnly = calcMethod(valid, 0);
    const avalanche = calcMethod(valid, ex, "avalanche");
    const snowball = calcMethod(valid, ex, "snowball");
    const aggressive = calcMethod(valid, ex*2.5);
    const avWins = avalanche.months <= snowball.months;
    const monthDiff = Math.abs(avalanche.months - snowball.months);
    const interestDiff = Math.abs(avalanche.interest - snowball.interest);
    const findB = (d,m) => { const f=d.filter(x=>x.month<=m); return f.length?f[f.length-1].balance:0; };
    const maxM = Math.max(avalanche.months, snowball.months);
    const step = Math.max(1, Math.floor(maxM/40));
    const h2hChart = [], allChart = [];
    const maxAll = Math.max(minOnly.months, aggressive.months);
    const stepAll = Math.max(1, Math.floor(maxAll/40));
    for (let m=0; m<=maxM; m+=step) h2hChart.push({ month:m, "Avalanche 🏔️":findB(avalanche.data,m), "Snowball ⛄":findB(snowball.data,m) });
    for (let m=0; m<=maxAll; m+=stepAll) allChart.push({ month:m, "Min Only":findB(minOnly.data,m), "Avalanche":findB(avalanche.data,m), "Snowball":findB(snowball.data,m), "Aggressive":findB(aggressive.data,m) });
    const tips = [];
    if ((totalMin/inc*100)>20) tips.push(`Your loan-to-income ratio is ${(totalMin/inc*100).toFixed(0)}% — above 20%. Even small income increases shift this significantly.`);
    if (valid.some(l=>parseFloat(l.rate)>7)) tips.push("Loans above 7% are your biggest cost center. Avalanche attacks these first.");
    if (monthDiff>0) tips.push(`Avalanche and Snowball differ by ${fmtYM(monthDiff)} here. ${avWins?"Avalanche is faster.":"Snowball is faster — your smallest loans carry higher rates."}`);
    tips.push("Set autopay on every loan — most lenders give a 0.25% rate discount automatically.");
    if (valid.length>2) tips.push("Refinancing multiple loans into one lower-rate loan could simplify everything and save thousands.");
    tips.push("Windfalls (tax refunds, bonuses) applied to your highest-rate loan have an outsized impact.");
    return { totalDebt, totalMin, minOnly, avalanche, snowball, aggressive, h2hChart, allChart, tips, ex, avWins, monthDiff, interestDiff };
  }, [done, loans, income, extra]);

  // What-if simulation
  const whatIfResults = useMemo(() => {
    if (!results) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const baseExtra = parseFloat(extra)||0;
    const totalExtra = baseExtra + whatIfExtra + whatIfHustle;
    const sim = calcMethod(valid, totalExtra, "avalanche");
    const base = results.avalanche;
    return {
      months: sim.months, interest: sim.interest,
      monthsSaved: base.months - sim.months,
      interestSaved: base.interest - sim.interest,
      monthlyPayment: results.totalMin + totalExtra,
    };
  }, [results, whatIfExtra, whatIfHustle, loans, extra]);

  // Side hustle impact
  const hustleImpact = useMemo(() => {
    if (!results || !selectedHustle) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const base = results.avalanche;
    const withHustle = calcMethod(valid, (parseFloat(extra)||0) + hustleAmount, "avalanche");
    return {
      monthsSaved: base.months - withHustle.months,
      interestSaved: base.interest - withHustle.interest,
      newMonths: withHustle.months,
    };
  }, [results, selectedHustle, hustleAmount, loans, extra]);

  // Tax deduction
  const taxCalc = useMemo(() => {
    if (!results) return null;
    const annualInterest = Math.min(results.avalanche.interest / (results.avalanche.months / 12), 2500);
    const deduction = Math.min(annualInterest, 2500);
    const taxSaving = deduction * taxBracket;
    const effectiveRate = loans.filter(l=>parseFloat(l.balance)>0).reduce((s,l)=>s+(parseFloat(l.rate)||0),0)/Math.max(1,loans.filter(l=>parseFloat(l.balance)>0).length);
    const afterTaxRate = effectiveRate * (1 - taxBracket);
    return { deduction, taxSaving, afterTaxRate };
  }, [results, taxBracket, loans]);

  // Progress tracker data
  const progressData = useMemo(() => {
    if (!results || !checkIns.length) return null;
    const totalDebt = results.totalDebt;
    const latest = checkIns[checkIns.length - 1];
    const paidOff = totalDebt - latest.balance;
    const pct = Math.max(0, Math.min(100, (paidOff / totalDebt) * 100));
    const earned = MILESTONE_DEFS.filter(m => pct >= m.pct);
    return { pct, paidOff, remaining: latest.balance, earned, latest };
  }, [results, checkIns]);

  // Forgiveness checker
  const searchForgiveness = async () => {
    setForgiveStatus("searching");
    const totalBal = loans.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    const annualIncome = (parseFloat(income)||0)*12;
    try {
      const res = await fetch("/api/anthropic", { method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:2500, tools:[{type:"web_search_20250305",name:"web_search"}],
          messages:[{ role:"user", content:`Search for student loan forgiveness programs in 2025 that someone with these details could qualify for:
- Employer type: ${forgiveEmployer}
- Job title: ${forgiveJobTitle||"not specified"}
- Years in current role: ${forgiveYears}
- Loan balance: $${Math.round(totalBal).toLocaleString()}
- Annual income: $${Math.round(annualIncome).toLocaleString()}

Search for: PSLF, Teacher Loan Forgiveness, TEACH Grant, Nurse Corps Loan Repayment, NHSC for doctors/nurses, state-specific programs, profession-based programs, income-driven repayment forgiveness. Include any 2025 updates.

Return ONLY JSON (no markdown):
{
  "programs": [
    {
      "name": "program name",
      "eligibility": "eligible|maybe|unlikely",
      "badge": "Likely Eligible|Check Requirements|Probably Not",
      "forgivenessAmount": "dollar amount or description e.g. 'Up to $17,500' or 'Remaining balance'",
      "timeline": "e.g. '10 years' or '5 years service'",
      "requirementsMet": "brief assessment of which requirements they meet",
      "description": "2 sentence explanation specific to their situation",
      "nextStep": "most important action to take",
      "learnMoreUrl": "real https URL to the official government or program website"
    }
  ],
  "topOpportunity": "name of best program for them",
  "summary": "2 sentence personalized summary of their forgiveness landscape"
}
Order from most to least relevant for this person. Include 3-5 programs.` }]
        })
      });
      const data = await res.json();
      const textBlock = data.content?.find(b=>b.type==="text");
      setForgiveData(JSON.parse(textBlock.text.replace(/```json|```/g,"").trim()));
      setForgiveStatus("done");
    } catch { setForgiveStatus("error"); }
  };

  // Salary ROI
  const salaryROI = useMemo(() => {
    if (!results) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const baseExtra = parseFloat(extra)||0;
    const monthlyRaiseAfterTax = (salaryRaise / 12) * (1 - taxBracket);
    const appliedToLoans = monthlyRaiseAfterTax * (salaryApplyPct / 100);
    const withRaise = calcMethod(valid, baseExtra + appliedToLoans, "avalanche");
    const base = results.avalanche;
    return {
      grossRaise: salaryRaise,
      monthlyNet: monthlyRaiseAfterTax,
      appliedMonthly: appliedToLoans,
      newMonths: withRaise.months,
      monthsSaved: base.months - withRaise.months,
      interestSaved: base.interest - withRaise.interest,
      newPayoff: withRaise.months,
    };
  }, [results, salaryRaise, salaryApplyPct, taxBracket, loans, extra]);

  // Partner combined
  const partnerResults = useMemo(() => {
    if (!partnerActive || !results) return null;
    const partnerValid = partnerLoans.filter(l => parseFloat(l.balance) > 0);
    if (!partnerValid.length) return null;
    const combinedLoans = [...loans.filter(l=>parseFloat(l.balance)>0), ...partnerValid];
    const combinedExtra = (parseFloat(extra)||0);
    const combined = calcMethod(combinedLoans, combinedExtra, "avalanche");
    const partnerOnly = calcMethod(partnerValid, 0);
    const youOnly = results.avalanche;
    const totalDebt = combinedLoans.reduce((s,l)=>s+(parseFloat(l.balance)||0),0);
    const totalMin = combinedLoans.reduce((s,l)=>s+(parseFloat(l.minPayment)||0),0);
    const combinedIncome = (parseFloat(income)||0) + (parseFloat(partnerIncome)||0);
    return { combined, partnerOnly, youOnly, totalDebt, totalMin, combinedIncome };
  }, [partnerActive, partnerLoans, partnerIncome, results, loans, income, extra]);

  const addPartnerLoan = () => { const id = idCtr++; setPartnerLoans(l=>[...l,{id,name:"",balance:"",rate:"",minPayment:""}]); };
  const removePartnerLoan = id => setPartnerLoans(l=>l.filter(x=>x.id!==id));
  const updatePartnerLoan = (id,f,v) => setPartnerLoans(l=>l.map(x=>x.id===id?{...x,[f]:v}:x));

  // Interest accrual calendar (12 months starting now + calYear offset)
  const interestCalendar = useMemo(() => {
    if (!results) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const now = new Date();
    const months = [];
    let balances = valid.map(l => parseFloat(l.balance)||0);
    const extra_pay = parseFloat(extra)||0;
    // Fast-forward calYear * 12 months
    for (let skip = 0; skip < calYear * 12; skip++) {
      let ex = extra_pay;
      balances = balances.map((b, i) => {
        if (b <= 0) return 0;
        const r = (parseFloat(valid[i].rate)||0)/100/12;
        b += b * r;
        b -= Math.min(parseFloat(valid[i].minPayment)||0, b);
        return Math.max(b, 0);
      });
      const sorted = [...valid.map((l,i)=>({...l,idx:i,b:balances[i]}))].sort((a,b_)=>(parseFloat(b_.rate)||0)-(parseFloat(a.rate)||0));
      for (const l of sorted) { if (l.b<=0||ex<=0) continue; const pay=Math.min(ex,l.b); balances[l.idx]-=pay; ex-=pay; }
    }
    const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    let maxInterest = 0;
    for (let m = 0; m < 12; m++) {
      let monthInterest = 0;
      const perLoan = [];
      let ex = extra_pay;
      balances = balances.map((b, i) => {
        if (b <= 0) return 0;
        const r = (parseFloat(valid[i].rate)||0)/100/12;
        const interest = b * r;
        monthInterest += interest;
        perLoan.push({ name: valid[i].name||`Loan ${i+1}`, interest, rate: parseFloat(valid[i].rate)||0 });
        b += interest;
        b -= Math.min(parseFloat(valid[i].minPayment)||0, b);
        return Math.max(b, 0);
      });
      const sorted = [...valid.map((l,i)=>({...l,idx:i,b:balances[i]}))].sort((a,b_)=>(parseFloat(b_.rate)||0)-(parseFloat(a.rate)||0));
      for (const l of sorted) { if (l.b<=0||ex<=0) continue; const pay=Math.min(ex,l.b); balances[l.idx]-=pay; ex-=pay; }
      const mi = Math.round(monthInterest);
      if (mi > maxInterest) maxInterest = mi;
      const mIdx = (now.getMonth() + m + calYear * 12) % 12;
      const yr = now.getFullYear() + Math.floor((now.getMonth() + m + calYear * 12) / 12);
      months.push({ label: `${monthNames[mIdx]} '${String(yr).slice(2)}`, interest: mi, perLoan });
    }
    const annualInterest = months.reduce((s,m)=>s+m.interest,0);
    // Loan breakdown for full year
    const loanTotals = valid.map((l,i) => ({
      name: l.name||`Loan ${i+1}`,
      total: months.reduce((s,m)=>s+(m.perLoan[i]?.interest||0),0),
      rate: parseFloat(l.rate)||0,
      color: ["#D96C45","#5B7FA6","#5A8A6A","#C89A2A","#7C5CBF","#C05A8A"][i % 6]
    }));
    return { months, annualInterest, loanTotals, maxInterest };
  }, [results, loans, extra, calYear]);

  // ── FULL AMORTIZATION TABLE ──
  const amortData = useMemo(() => {
    if (!results) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const extra_pay = parseFloat(extra)||0;
    // Build per-loan amortization (ignoring cascade for simplicity — clean per-loan view)
    return valid.map(loan => {
      const bal0 = parseFloat(loan.balance)||0;
      const rate = (parseFloat(loan.rate)||0)/100/12;
      const minPay = parseFloat(loan.minPayment)||0;
      // Each loan gets its proportional share of extra
      const totalMin = valid.reduce((s,l)=>s+(parseFloat(l.minPayment)||0),0);
      const loanExtraShare = totalMin > 0 ? (minPay/totalMin)*extra_pay : 0;
      const payment = minPay + loanExtraShare;
      const rows = [];
      let b = bal0, totalInterest = 0, totalPrincipal = 0;
      let month = 0;
      while (b > 0.01 && month < 600) {
        month++;
        const interest = b * rate;
        const principal = Math.min(Math.max(payment - interest, 0), b);
        b = Math.max(b - principal, 0);
        totalInterest += interest;
        totalPrincipal += principal;
        rows.push({ month, payment: Math.round(principal+interest), interest: Math.round(interest), principal: Math.round(principal), balance: Math.round(b) });
      }
      return { name: loan.name||'Loan', rows, totalInterest: Math.round(totalInterest), totalPrincipal: Math.round(totalPrincipal), months: month };
    });
  }, [results, loans, extra]);

  // ── PAYOFF ORDER STEP-BY-STEP ──
  const payoffOrder = useMemo(() => {
    if (!results) return null;
    const valid = loans.filter(l => parseFloat(l.balance) > 0);
    const ex = parseFloat(extra)||0;
    // Simulate avalanche step by step, track when each loan hits 0
    let bl = valid.map(l => ({ ...l, b: parseFloat(l.balance)||0, interestPaid: 0 }));
    let month = 0;
    const steps = [];
    const paidOff = new Set();
    const now = new Date();
    while (bl.some(l => l.b > 0.01) && month < 600) {
      month++;
      let ex2 = ex;
      for (const l of bl) {
        if (l.b <= 0) continue;
        const r = (parseFloat(l.rate)||0)/100/12;
        l.interestPaid += l.b * r;
        l.b += l.b * r;
        l.b -= Math.min(parseFloat(l.minPayment)||0, l.b);
        if (l.b < 0) l.b = 0;
      }
      const sorted = [...bl].sort((a,b) => (parseFloat(b.rate)||0)-(parseFloat(a.rate)||0));
      for (const l of sorted) {
        if (l.b <= 0 || ex2 <= 0) continue;
        const pay = Math.min(ex2, l.b); l.b -= pay; ex2 -= pay;
      }
      // Check newly paid off loans
      for (const l of bl) {
        if (l.b <= 0.01 && !paidOff.has(l.id||l.name)) {
          paidOff.add(l.id||l.name);
          const payoffDate = new Date(now);
          payoffDate.setMonth(payoffDate.getMonth() + month);
          const freed = parseFloat(l.minPayment)||0;
          steps.push({ name: l.name||'Loan', month, date: payoffDate.toLocaleDateString('en-US',{month:'short',year:'numeric'}), interestPaid: Math.round(l.interestPaid), rate: parseFloat(l.rate)||0, freed, stepNum: steps.length+1 });
        }
      }
    }
    // Build cascading narrative
    return steps.map((s, i) => ({
      ...s,
      freedTotal: steps.slice(0, i+1).reduce((sum,st)=>sum+st.freed, 0),
      action: i < steps.length-1 ? `Roll the freed ${fmt(s.freed)}/mo into "${steps[i+1]?.name}"` : "🎉 All loans paid off! You're debt free!"
    }));
  }, [results, loans, extra]);

  const UploadZone = ({ files, setFiles, drag, setDrag, cls="", icon, title, sub }) => (
    <div className={`upload-zone${cls}${drag?" drag-over":""}`}
      onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)}
      onDrop={e=>{e.preventDefault();setDrag(false);handleFiles(e.dataTransfer.files,setFiles);}}>
      <input type="file" accept=".pdf,image/*" multiple onChange={e=>handleFiles(e.target.files,setFiles)}/>
      <div className="upload-icon">{icon}</div>
      <div className="upload-title">{title}</div>
      <div className="upload-sub" dangerouslySetInnerHTML={{__html:sub}}/>
    </div>
  );

  return (
    <div className="app" id="app-root">
      <style>{css}</style>
      <div className="blob blob-1"/><div className="blob blob-2"/><div className="blob blob-3"/>
      <Confetti show={showConfetti}/>
      {celebrationMsg && <div className="celebration-banner">{celebrationMsg}</div>}
      {shareToast && <div className="share-toast">✅ Link copied to clipboard!</div>}

      {/* Toolbar */}
      <div className="toolbar">
        <button className="toolbar-btn" title="Toggle dark mode" onClick={()=>setDarkMode(d=>!d)}>{darkMode?"☀️":"🌙"}</button>
        <button className="toolbar-btn" title="Share plan" onClick={shareURL}>🔗</button>
        <button className="toolbar-btn" title="Print / Save PDF" onClick={()=>window.print()}>🖨️</button>
      </div>

      {/* Bottom Nav — visible on mobile only */}
      <nav className="bottom-nav">
        {[
          {id:"setup",   icon:"📋", label:"Loans"},
          {id:"results", icon:"📊", label:"Plan"},
          {id:"tools",   icon:"🛠️", label:"Tools"},
          {id:"ai",      icon:"🤖", label:"AI"},
          {id:"progress",icon:"🎯", label:"Track"},
        ].map(n=>(
          <button key={n.id} className={`bnav-item${activeSection===n.id?" active":""}`}
            onClick={()=>{ const el=document.getElementById('sec-'+n.id); el?.scrollIntoView({behavior:'smooth',block:'start'}); }}>
            <span className="bnav-icon">{n.icon}</span>{n.label}
          </button>
        ))}
      </nav>

      <div className="inner">
        <header className="header">
          <div className="header-badge">Student Loan Payoff Planner</div>
          <h1>Get out of debt<br/><em>smarter & faster</em></h1>
          <p className="header-sub">Upload your docs, simulate scenarios, track progress, and find the fastest path to debt freedom.</p>
        </header>

        {/* ── SECTION: SETUP ── */}
        <div id="sec-setup" className="section-anchor">
          <div className="section-label"><span className="icon-badge orange">🤖</span>Step 1 — Import Loan Documents</div>
          <UploadZone files={loanFiles} setFiles={setLoanFiles} drag={loanDrag} setDrag={setLoanDrag} icon="📂" title="Drop loan statements here" sub="Supports <strong>PDFs & images</strong> — servicer statements, NSLDS downloads, screenshots"/>
          {loanFiles.length>0&&<div className="upload-files-list">{loanFiles.map(f=><div className="upload-file-chip" key={f.name}><span className="file-icon">{getFileIcon(f)}</span><span className="file-name">{f.name}</span><span style={{fontSize:"0.72rem",color:"var(--text-light)"}}>{(f.size/1024).toFixed(0)} KB</span><button className="remove-file" onClick={()=>setLoanFiles(p=>p.filter(x=>x.name!==f.name))}>×</button></div>)}</div>}
          {loanParseStatus==="parsing"?<div className="parsing-state"><div className="spinner"/><div className="parsing-label">Reading documents…</div></div>:loanFiles.length>0&&<button className="btn-parse" onClick={parseLoanDocs}>✨ Extract loan info automatically</button>}
          {loanParseStatus==="success"&&<div className="parse-success"><span className="parse-success-icon">✅</span><div className="parse-success-text">Loans imported!<span>{loanParseMsg}</span></div></div>}
          {loanParseStatus==="error"&&<div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">{loanParseMsg}</div></div>}
          <div className="divider-row"><div className="divider-line"/><div className="divider-text">or enter manually</div><div className="divider-line"/></div>
          <div className="section-label" style={{marginBottom:"1rem"}}><span className="icon-badge orange">📋</span>Your Loans</div>
          <div className="col-heads"><div className="col-head">Loan Name</div><div className="col-head">Balance</div><div className="col-head">Rate %</div><div className="col-head">Min. Payment</div><div/></div>
          <div className="loans-list">{loans.map(loan=>(
            <div className={`loan-row${newLoanIds.has(loan.id)?" new-loan":""}`} key={loan.id}>
              <input placeholder="Loan name (e.g. Federal Sub)" value={loan.name} onChange={e=>update(loan.id,"name",e.target.value)} className={newLoanIds.has(loan.id)?"highlighted":""}/>
              <input type="number" placeholder="Balance $" value={loan.balance} onChange={e=>update(loan.id,"balance",e.target.value)} className={newLoanIds.has(loan.id)?"highlighted":""}/>
              <input type="number" placeholder="Rate %" step="0.01" value={loan.rate} onChange={e=>update(loan.id,"rate",e.target.value)} className={newLoanIds.has(loan.id)?"highlighted":""}/>
              <input type="number" placeholder="Min. payment $" value={loan.minPayment} onChange={e=>update(loan.id,"minPayment",e.target.value)} className={newLoanIds.has(loan.id)?"highlighted":""}/>
              <button className="btn-remove" onClick={()=>remove(loan.id)}>×</button>
            </div>
          ))}</div>
          <button className="btn-add" onClick={addLoan}>＋ Add another loan</button>
        </div>

        {/* Step 2: Budget */}
        <div className="card">
          <div className="section-label"><span className="icon-badge blue">💰</span>Step 2 — Upload Your Budget</div>
          <UploadZone files={budgetFiles} setFiles={setBudgetFiles} drag={budgetDrag} setDrag={setBudgetDrag} cls=" blue-zone" icon="📊" title="Drop budget or bank statement" sub='Supports <strong class="blue">PDFs & images</strong> — bank statements, expense trackers, pay stubs'/>
          {budgetFiles.length>0&&<div className="upload-files-list">{budgetFiles.map(f=><div className="upload-file-chip" key={f.name}><span className="file-icon">{getFileIcon(f)}</span><span className="file-name">{f.name}</span><span style={{fontSize:"0.72rem",color:"var(--text-light)"}}>{(f.size/1024).toFixed(0)} KB</span><button className="remove-file" onClick={()=>setBudgetFiles(p=>p.filter(x=>x.name!==f.name))}>×</button></div>)}</div>}
          {budgetParseStatus==="parsing"?<div className="parsing-state"><div className="spinner blue"/><div className="parsing-label">Analyzing budget…</div></div>:budgetFiles.length>0&&<button className="btn-parse" onClick={parseBudgetDoc}>📊 Analyze my budget automatically</button>}
          {budgetParseStatus==="success"&&<div className="parse-success"><span className="parse-success-icon">✅</span><div className="parse-success-text">Budget analyzed!<span>{budgetParseMsg}</span></div></div>}
          {budgetParseStatus==="error"&&<div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">{budgetParseMsg}</div></div>}

          <div className="divider-row"><div className="divider-line"/><div className="divider-text">or import bank CSV</div><div className="divider-line"/></div>
          <div className={`csv-zone${csvDrag?" drag-over":""}`}
            onDragOver={e=>{e.preventDefault();setCsvDrag(true);}} onDragLeave={()=>setCsvDrag(false)}
            onDrop={e=>{e.preventDefault();setCsvDrag(false);const f=e.dataTransfer.files[0];if(f?.name.endsWith('.csv'))handleCSVFile(f);}}>
            <input type="file" accept=".csv" onChange={e=>handleCSVFile(e.target.files[0])}/>
            <div style={{fontSize:"1.6rem",marginBottom:"0.4rem"}}>🏦</div>
            <div className="upload-title" style={{fontSize:"0.9rem"}}>Drop your bank CSV export here</div>
            <div className="upload-sub">Most banks let you download transactions as CSV — Chase, BofA, Wells Fargo, Citi & more. We auto-categorize spending and detect your surplus.</div>
          </div>
          {csvResult?.error && <div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">{csvResult.error}</div></div>}
          {csvResult && !csvResult.error && (
            <div className="csv-result">
              <div className="csv-result-title">📊 Transactions Analyzed — {csvResult.categories.length} spending categories found</div>
              <div className="csv-cats">
                {csvResult.categories.map((c,i)=><div className="csv-cat-row" key={i}><span className="csv-cat-name">{c.name}</span><span className="csv-cat-amt">{fmt(c.amount)}</span></div>)}
              </div>
              <div className="csv-surplus-row">
                <span className="csv-surplus-label">Estimated Monthly Surplus</span>
                <span className={`csv-surplus-val${csvResult.surplus<200?" ":" "}`} style={{color:csvResult.surplus>=200?"var(--sage)":"var(--terracotta)"}}>{fmt(Math.max(0,csvResult.surplus))}</span>
              </div>
              <div style={{fontSize:"0.73rem",color:"var(--sage)",marginTop:"0.5rem",fontWeight:600}}>✓ Income ({fmt(csvResult.totalIncome)}/mo) and extra budget auto-filled below</div>
            </div>
          )}
          {budgetData&&parseFloat(budgetData.availableSurplus)>=0&&(
            <div className="budget-breakdown">
              <div className="budget-breakdown-title">📋 Budget Breakdown</div>
              <div className="budget-row-grid">{budgetData.expenses?.map((e,i)=><div className="budget-item" key={i}><span className="budget-item-label">{e.name}</span><span className="budget-item-val">{fmt(parseFloat(e.amount)||0)}</span></div>)}</div>
              <div className="budget-surplus-row"><div><div className="budget-surplus-label">Monthly Surplus</div><div style={{fontSize:"0.75rem",color:"var(--text-light)"}}>After income & expenses</div></div><div className={`budget-surplus-val${parseFloat(budgetData.availableSurplus)<200?" tight":""}`}>{fmt(parseFloat(budgetData.availableSurplus)||0)}</div></div>
            </div>
          )}
          <div className="divider-row"><div className="divider-line"/><div className="divider-text">or enter manually</div><div className="divider-line"/></div>
          <div className="manual-budget-row">
            <div className="field-group"><label>Monthly Take-Home Income</label><input type="number" placeholder="5000" value={income} onChange={e=>setIncome(e.target.value)}/>{budgetData&&parseFloat(budgetData.monthlyIncome)>0&&<div className="field-hint green">✓ Auto-filled</div>}</div>
            <div className="field-group"><label>Extra Monthly Budget for Loans</label><input type="number" placeholder="300" value={extra} onChange={e=>setExtra(e.target.value)}/>{budgetData&&parseFloat(budgetData.availableSurplus)>0&&<div className="field-hint green">✓ Auto-filled from surplus</div>}</div>
          </div>
          <button className="btn-cta" onClick={()=>{setDone(true);setRefiStatus("idle");setFedStatus("idle");setWhatIfExtra(0);setWhatIfHustle(0);}}>Build my payoff plan 🎯</button>
        </div>

        {results && (
          <div className="results">
            {/* ── SECTION: RESULTS ── */}
            <div id="sec-results" className="section-anchor"/>
            {/* Summary */}
            <div className="summary-row">
              <div className="summary-tile"><div className="tile-label">Total Debt</div><div className="tile-value">{fmt(results.totalDebt)}</div><div className="tile-sub">{loans.filter(l=>parseFloat(l.balance)>0).length} loan(s)</div></div>
              <div className="summary-tile"><div className="tile-label">Min. Monthly</div><div className="tile-value">{fmt(results.totalMin)}</div><div className="tile-sub">{(results.totalMin/(parseFloat(income)||1)*100).toFixed(0)}% of income</div></div>
              <div className="summary-tile"><div className="tile-label">Extra/Month</div><div className="tile-value" style={{color:"var(--blue)"}}>{fmt(results.ex)}</div><div className="tile-sub">toward payoff</div></div>
              <div className="summary-tile"><div className="tile-label">Interest Saved</div><div className="tile-value green">{fmt(results.minOnly.interest-results.avalanche.interest)}</div><div className="tile-sub">Avalanche vs min</div></div>
            </div>

            {/* ── SECTION: TOOLS ── */}
            <div id="sec-tools" className="section-anchor"/>

            {/* ── WHAT-IF SIMULATOR ── */}
            <div className="whatif-card">
              <div className="section-label" style={{marginBottom:"0.5rem"}}><span className="icon-badge orange">🎛️</span>What-If Simulator</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.5rem",lineHeight:"1.55"}}>Drag the sliders and watch your payoff date update in real time. See exactly what each extra dollar does.</p>
              <div className="whatif-sliders">
                <div className="slider-group">
                  <label>
                    <span className="slider-label-text">Extra monthly payment</span>
                    <span className="slider-label-val">{fmt(whatIfExtra)}/mo</span>
                  </label>
                  <input type="range" min={0} max={1500} step={25} value={whatIfExtra} onChange={e=>setWhatIfExtra(Number(e.target.value))}
                    style={{background:`linear-gradient(to right, var(--terracotta) 0%, var(--terracotta) ${whatIfExtra/15}%, var(--cream) ${whatIfExtra/15}%, var(--cream) 100%)`}}/>
                </div>
                <div className="slider-group">
                  <label>
                    <span className="slider-label-text">Side hustle income applied to loans</span>
                    <span className="slider-label-val blue">{fmt(whatIfHustle)}/mo</span>
                  </label>
                  <input type="range" className="blue-thumb" min={0} max={1500} step={25} value={whatIfHustle} onChange={e=>setWhatIfHustle(Number(e.target.value))}
                    style={{background:`linear-gradient(to right, var(--blue) 0%, var(--blue) ${whatIfHustle/15}%, var(--cream) ${whatIfHustle/15}%, var(--cream) 100%)`}}/>
                </div>
              </div>
              {whatIfResults && (
                <div className="whatif-results-grid">
                  <div className="whatif-tile">
                    <div className="whatif-tile-label">New Payoff Time</div>
                    <div className={`whatif-tile-val${whatIfResults.monthsSaved>0?" green":""}`}>{fmtYM(whatIfResults.months)}</div>
                    {whatIfResults.monthsSaved>0?<div className="whatif-tile-delta better">↓ {fmtYM(whatIfResults.monthsSaved)} sooner</div>:<div className="whatif-tile-delta" style={{color:"var(--text-light)"}}>No change yet</div>}
                  </div>
                  <div className="whatif-tile">
                    <div className="whatif-tile-label">Interest Saved</div>
                    <div className={`whatif-tile-val${whatIfResults.interestSaved>0?" green":""}`}>{fmt(Math.max(0,whatIfResults.interestSaved))}</div>
                    {whatIfResults.interestSaved>0&&<div className="whatif-tile-delta better">↓ vs. your current plan</div>}
                  </div>
                  <div className="whatif-tile">
                    <div className="whatif-tile-label">Monthly Payment</div>
                    <div className={`whatif-tile-val${(whatIfExtra+whatIfHustle)>0?" orange":""}`}>{fmt(whatIfResults.monthlyPayment)}</div>
                    {(whatIfExtra+whatIfHustle)>0&&<div className="whatif-tile-delta worse">↑ {fmt(whatIfExtra+whatIfHustle)} more/mo</div>}
                  </div>
                </div>
              )}
            </div>

            {/* H2H */}
            <div className="h2h-card">
              <div className="h2h-title">⚔️ Avalanche vs. Snowball</div>
              <div className="h2h-sub">Head-to-head for your exact loans with {fmt(results.ex)}/mo extra</div>
              <div className="h2h-grid">
                <div className={`h2h-side avalanche${results.avWins?" winner":""}`}>
                  {results.avWins&&<div className="winner-crown">🏆 Winner</div>}
                  <div className="h2h-method-name orange">🏔️ Avalanche</div>
                  <div className="h2h-method-tag">Highest interest rate first</div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Payoff Time</div><div className={`h2h-stat-val${results.avWins?" highlight-orange":""}`}>{fmtYM(results.avalanche.months)}</div></div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Total Interest</div><div className="h2h-stat-val red">{fmt(results.avalanche.interest)}</div></div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Monthly Payment</div><div className="h2h-stat-val">{fmt(results.totalMin+results.ex)}</div></div>
                  {results.avWins&&results.monthDiff>0&&<><div className="h2h-stat" style={{marginTop:"0.5rem",paddingTop:"0.5rem",borderTop:"1px solid rgba(217,108,69,0.2)"}}><div className="h2h-stat-label">Faster by</div><div className="h2h-stat-val green">−{fmtYM(results.monthDiff)}</div></div></>}
                </div>
                <div className="h2h-vs"><div className="vs-circle">VS</div></div>
                <div className={`h2h-side snowball${!results.avWins?" winner":""}`}>
                  {!results.avWins&&<div className="winner-crown blue">🏆 Winner</div>}
                  <div className="h2h-method-name blue-c">⛄ Snowball</div>
                  <div className="h2h-method-tag">Smallest balance first</div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Payoff Time</div><div className={`h2h-stat-val${!results.avWins?" highlight-blue":""}`}>{fmtYM(results.snowball.months)}</div></div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Total Interest</div><div className="h2h-stat-val red">{fmt(results.snowball.interest)}</div></div>
                  <div className="h2h-stat"><div className="h2h-stat-label">Monthly Payment</div><div className="h2h-stat-val">{fmt(results.totalMin+results.ex)}</div></div>
                  {!results.avWins&&results.monthDiff>0&&<><div className="h2h-stat" style={{marginTop:"0.5rem",paddingTop:"0.5rem",borderTop:"1px solid rgba(91,127,166,0.2)"}}><div className="h2h-stat-label">Faster by</div><div className="h2h-stat-val green">−{fmtYM(results.monthDiff)}</div></div></>}
                </div>
              </div>
              <div className="h2h-verdict">
                {results.monthDiff===0?<><div className="verdict-title">It's a tie! 🤝</div><div className="verdict-text">Both finish at the same time. Avalanche saves more interest; Snowball gives faster psychological wins.</div></> : results.avWins ? <><div className="verdict-winner-pill orange">🏔️ Avalanche Wins</div><div className="verdict-title">Avalanche is faster for your loans</div><div className="verdict-text">Targeting highest-rate loans first gets you debt-free {fmtYM(results.monthDiff)} sooner{results.interestDiff>100&&` and saves ${fmt(results.interestDiff)} in interest`}.</div></> : <><div className="verdict-winner-pill blue-p">⛄ Snowball Wins</div><div className="verdict-title">Snowball is faster for your loans</div><div className="verdict-text">Snowball beats Avalanche by {fmtYM(results.monthDiff)} — your smaller loans carry higher rates, so clearing them first cascades extra cash.</div></>}
              </div>
              <div style={{marginTop:"1.5rem"}}>
                <div className="chart-card-title">Balance Race</div>
                <div className="chart-sub">Month-by-month competition to zero</div>
                <MiniAreaChart data={results.h2hChart} height={220} series={[
                  {key:"Avalanche 🏔️", label:"Avalanche 🏔️", color:"#D96C45", width:2.5},
                  {key:"Snowball ⛄",   label:"Snowball ⛄",   color:"#5B7FA6", width:2.5},
                ]}/>
              </div>
            </div>

            {/* All strategies */}
            <div className="card">
              <div className="section-label"><span className="icon-badge sage">📈</span>All Payoff Strategies</div>
              <div className="strategies-grid">
                {[
                  {emoji:"🐢",name:"Min. Payments",desc:"Pay only what's required.",months:results.minOnly.months,interest:results.minOnly.interest,monthly:results.totalMin,cls:"",ribbon:null},
                  {emoji:"🏔️",name:"Avalanche",desc:"Highest interest first.",months:results.avalanche.months,interest:results.avalanche.interest,monthly:results.totalMin+results.ex,cls:" featured",ribbon:{label:results.avWins?"Fastest":"Best $",color:"orange"}},
                  {emoji:"⛄",name:"Snowball",desc:"Smallest balance first.",months:results.snowball.months,interest:results.snowball.interest,monthly:results.totalMin+results.ex,cls:" featured-blue",ribbon:{label:!results.avWins?"Fastest":"Motivating",color:"blue-r"}},
                  {emoji:"🚀",name:"Aggressive",desc:"2.5× extra. Transformative if manageable.",months:results.aggressive.months,interest:results.aggressive.interest,monthly:results.totalMin+results.ex*2.5,cls:"",ribbon:null},
                ].map(s=>(
                  <div key={s.name} className={`strat-card${s.cls}`}>
                    {s.ribbon&&<div className={`feat-ribbon ${s.ribbon.color}`}>{s.ribbon.label}</div>}
                    <div className="strat-emoji">{s.emoji}</div><div className="strat-name">{s.name}</div><div className="strat-desc">{s.desc}</div>
                    <div className="strat-stats">
                      <div className="strat-stat"><span className="ss-label">Payoff time</span><span className={`ss-val ${s.cls.includes("blue")?"blue-v":"accent"}`}>{fmtYM(s.months)}</span></div>
                      <div className="strat-stat"><span className="ss-label">Total interest</span><span className="ss-val red">{fmt(s.interest)}</span></div>
                      <div className="strat-stat"><span className="ss-label">Monthly</span><span className="ss-val">{fmt(s.monthly)}</span></div>
                      {s.ribbon&&<><div className="divider-stat"/><div className="strat-stat"><span className="ss-label">Saved vs min</span><span className="ss-val green">−{fmtYM(results.minOnly.months-s.months)}</span></div></>}
                    </div>
                  </div>
                ))}
              </div>
              <div className="chart-card-title">All Strategies Over Time</div>
              <div className="chart-sub">Full picture including minimum and aggressive payoff</div>
              <MiniAreaChart data={results.allChart} height={220} series={[
                {key:"Min Only",   label:"Min Only",   color:"#E07070", width:1.5},
                {key:"Avalanche",  label:"Avalanche",  color:"#D96C45", width:2},
                {key:"Snowball",   label:"Snowball",   color:"#5B7FA6", width:2},
                {key:"Aggressive", label:"Aggressive", color:"#5A8A6A", width:1.5},
              ]}/>
            </div>

            {/* ── SECTION: PROGRESS ── */}
            <div id="sec-progress" className="section-anchor"/>

            {/* ── PROGRESS TRACKER ── */}
            <div className="progress-card">
              <div className="progress-header">
                <div className="progress-header-text">
                  <h3>📅 Progress Tracker</h3>
                  <p>Log your balance monthly — we'll track your real progress vs. the plan</p>
                </div>
                {checkIns.length>0&&<button className="btn-sm red" onClick={async()=>{setCheckIns([]);try{localStorage.removeItem("checkins");}catch{}}}>Clear</button>}
              </div>

              {progressData && (
                <div className="overall-progress">
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:"0.78rem",fontWeight:700,color:"var(--text-mid)",marginBottom:"0.3rem"}}>
                    <span>Paid off {fmt(progressData.paidOff)} ({progressData.pct.toFixed(1)}%)</span>
                    <span style={{color:"var(--text-light)"}}>Remaining: {fmt(progressData.remaining)}</span>
                  </div>
                  <div className="progress-bar-track"><div className="progress-bar-fill" style={{width:`${progressData.pct}%`}}/></div>
                  <div className="progress-bar-label"><span>Start: {fmt(results.totalDebt)}</span><span>Goal: $0</span></div>
                  <div className="milestones-row">
                    {MILESTONE_DEFS.map(m=>(
                      <div key={m.id} className={`milestone-chip ${progressData.earned.some(e=>e.id===m.id)?"earned":"locked"}`}>
                        {m.icon} {m.label}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {checkIns.length > 0 && (
                <div className="checkin-list">
                  {[...checkIns].reverse().map((c, i) => {
                    const prev = checkIns[checkIns.length - 1 - i - 1];
                    const delta = prev ? prev.balance - c.balance : results.totalDebt - c.balance;
                    const pct = Math.max(0, Math.min(100, ((results.totalDebt - c.balance) / results.totalDebt) * 100));
                    return (
                      <div className="checkin-row" key={c.ts}>
                        <span className="checkin-date">{c.date}</span>
                        <div className="checkin-bar"><div className="checkin-bar-fill" style={{width:`${pct}%`}}/></div>
                        <span className="checkin-amount">{fmt(c.balance)}</span>
                        <span className="checkin-delta">-{fmt(delta)}</span>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="add-checkin">
                <div className="add-checkin-title">Log this month's balance</div>
                <div className="checkin-inputs">
                  <div className="field-group"><label>Date</label><input type="date" value={checkInDate} onChange={e=>setCheckInDate(e.target.value)}/></div>
                  <div className="field-group"><label>Current Total Balance</label><input type="number" placeholder="40000" value={checkInBalance} onChange={e=>setCheckInBalance(e.target.value)}/></div>
                  <button className="btn-log" onClick={addCheckIn}>Log it →</button>
                </div>
              </div>
            </div>

            {/* ── SIDE HUSTLE CALCULATOR ── */}
            <div className="hustle-card">
              <div className="section-label"><span className="icon-badge pink">💼</span>Side Hustle Impact Calculator</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.25rem",lineHeight:"1.55"}}>Pick a side hustle and see exactly how many months it shaves off your debt timeline.</p>
              <div className="hustle-options">
                {HUSTLE_OPTIONS.map(h=>(
                  <div key={h.id} className={`hustle-chip${selectedHustle===h.id?" active":""}`} onClick={()=>{setSelectedHustle(h.id);setHustleAmount(h.default);}}>
                    <div className="hustle-chip-icon">{h.icon}</div>
                    <div className="hustle-chip-label">{h.label}</div>
                    <div className="hustle-chip-earn">{fmt(h.range[0])}–{fmt(h.range[1])}/mo</div>
                  </div>
                ))}
              </div>
              {selectedHustle && (
                <>
                  <div className="slider-group" style={{marginBottom:"1rem"}}>
                    <label style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:"0.6rem"}}>
                      <span style={{fontSize:"0.78rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"var(--text-mid)"}}>Monthly hustle income applied to loans</span>
                      <span style={{fontFamily:"'Fraunces',serif",fontSize:"1.1rem",fontWeight:900,color:"var(--pink)"}}>{fmt(hustleAmount)}/mo</span>
                    </label>
                    <input type="range" style={{background:`linear-gradient(to right, var(--pink) 0%, var(--pink) ${(hustleAmount-100)/9}%, var(--cream) ${(hustleAmount-100)/9}%, var(--cream) 100%)`,"--thumb-color":"var(--pink)"}}
                      min={100} max={1000} step={50} value={hustleAmount} onChange={e=>setHustleAmount(Number(e.target.value))}/>
                  </div>
                  {hustleImpact && (
                    <div className="hustle-impact">
                      <div className="hustle-impact-title">🎉 With {fmt(hustleAmount)}/mo from {HUSTLE_OPTIONS.find(h=>h.id===selectedHustle)?.label}…</div>
                      <div className="hustle-impact-grid">
                        <div><div className="hustle-stat-label">New Payoff Time</div><div className="hustle-stat-val">{fmtYM(hustleImpact.newMonths)}</div></div>
                        <div><div className="hustle-stat-label">Months Shaved Off</div><div className="hustle-stat-val">{fmtYM(hustleImpact.monthsSaved)}</div></div>
                        <div><div className="hustle-stat-label">Interest Saved</div><div className="hustle-stat-val">{fmt(hustleImpact.interestSaved)}</div></div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* ── TAX DEDUCTION TRACKER ── */}
            <div className="tax-card">
              <div className="section-label"><span className="icon-badge gold">🧾</span>Student Loan Tax Deduction</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.25rem",lineHeight:"1.55"}}>You can deduct up to <strong>$2,500/year</strong> in student loan interest from your taxable income. Here's what that means for you.</p>
              <div style={{marginBottom:"1rem"}}>
                <div style={{fontSize:"0.72rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"var(--text-light)",marginBottom:"0.6rem"}}>Your tax bracket</div>
                <div className="tax-bracket-row">
                  {TAX_BRACKETS.map(b=>(
                    <button key={b.rate} className={`tax-bracket-btn${taxBracket===b.rate?" active":""}`} onClick={()=>setTaxBracket(b.rate)}>{b.label}</button>
                  ))}
                </div>
              </div>
              {taxCalc && (
                <div className="tax-breakdown">
                  <div className="tax-stat"><div className="tax-stat-label">Max Annual Deduction</div><div className="tax-stat-val gold">{fmt(taxCalc.deduction)}</div></div>
                  <div className="tax-stat"><div className="tax-stat-label">Tax $ Saved/Year</div><div className="tax-stat-val gold">{fmt(taxCalc.taxSaving)}</div></div>
                  <div className="tax-stat"><div className="tax-stat-label">Effective After-Tax Rate</div><div className="tax-stat-val">{taxCalc.afterTaxRate.toFixed(2)}%</div></div>
                </div>
              )}
              <div className="tax-note">⚠️ The deduction phases out at higher incomes ($75k–$90k single, $155k–$185k married filing jointly for 2024). Consult a tax professional for your exact situation. Apply for your deduction using Form 1098-E from your servicer.</div>
            </div>

            {/* ── SECTION: AI ── */}
            <div id="sec-ai" className="section-anchor"/>

            {/* Refinancing */}
            <div className="refi-section">
              <div className="section-label"><span className="icon-badge gold">🔍</span>Refinancing Opportunities</div>
              <div className="refi-intro">Refinancing replaces your loans with a new one at a lower rate — potentially saving thousands. <strong>Your current avg rate: {(loans.filter(l=>parseFloat(l.balance)>0).reduce((s,l)=>s+(parseFloat(l.rate)||0),0)/Math.max(1,loans.filter(l=>parseFloat(l.balance)>0).length)).toFixed(2)}%.</strong> We'll search live lender rates and compare.</div>
              {refiStatus==="idle"&&<button className="btn-refi" onClick={searchRefinancing}>🔍 Search Current Refinancing Rates</button>}
              {refiStatus==="searching"&&<div className="parsing-state"><div className="spinner gold"/><div className="parsing-label">Searching lender rates…</div><div className="parsing-sub">Comparing SoFi, Earnest, ELFI, Splash & more</div></div>}
              {refiStatus==="error"&&<div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">Couldn't fetch rates. Try again or visit lender sites directly.</div></div>}
              {refiStatus==="done"&&refiData&&(
                <div>
                  {parseFloat(refiData.totalSavings)>0&&<div className="refi-savings-banner"><div><div className="rsb-label">Estimated Total Interest Savings</div><div className="rsb-sub">refinancing at {refiData.bestRefiRate}% vs. your {refiData.currentAvgRate}%</div></div><div className="rsb-val">{fmt(parseFloat(refiData.totalSavings))}</div></div>}
                  <div className="refi-comparison-grid">
                    <div className="refi-current-card"><div className="refi-card-label">Current Situation</div><div className="refi-card-stat"><div className="refi-card-stat-label">Avg Rate</div><div className="refi-card-stat-val red">{refiData.currentAvgRate}%</div></div><div className="refi-card-stat"><div className="refi-card-stat-label">Payoff</div><div className="refi-card-stat-val">{fmtYM(results.avalanche.months)}</div></div><div className="refi-card-stat"><div className="refi-card-stat-label">Total Interest</div><div className="refi-card-stat-val red">{fmt(results.avalanche.interest)}</div></div></div>
                    <div className="refi-new-card"><div className="refi-card-label" style={{color:"var(--gold)"}}>After Refinancing</div><div className="refi-card-stat"><div className="refi-card-stat-label">Best Rate</div><div className="refi-card-stat-val gold">{refiData.bestRefiRate}%</div></div><div className="refi-card-stat"><div className="refi-card-stat-label">Est. Payoff</div><div className="refi-card-stat-val green">{fmtYM(parseInt(refiData.newPayoffMonths)||results.avalanche.months)}</div></div><div className="refi-card-stat"><div className="refi-card-stat-label">Monthly Savings</div><div className="refi-card-stat-val green">{fmt(parseFloat(refiData.monthlySavings)||0)}/mo</div></div></div>
                  </div>
                  <div style={{marginBottom:"0.75rem",fontFamily:"'Fraunces',serif",fontSize:"1rem",fontWeight:700,color:"var(--text-dark)"}}>Top Lenders</div>
                  <div className="refi-lenders">{refiData.lenders?.map((l,i)=><a className="lender-card" key={i} href={l.url||"#"} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none"}}><div style={{flex:1}}><div className="lender-name">{l.name}</div><div className="lender-type">{l.highlight}</div></div><div style={{textAlign:"right"}}><div className="lender-rate">{l.rateRange}</div><div className="lender-type">{l.fixedOrVariable}</div></div>{i===0&&<div className="lender-badge">Best Rate</div>}{l.url&&<div style={{fontSize:"0.7rem",color:"var(--terracotta)",marginLeft:"0.5rem"}}>↗</div>}</a>)}</div>
                  {refiData.recommendation&&<div className="tip-item" style={{marginBottom:"0.75rem"}}><div className="tip-dot" style={{background:"var(--gold)"}}/><div className="tip-text">{refiData.recommendation}</div></div>}
                  {refiData.refinanceWarnings?.length>0&&<div className="refi-warning"><span className="refi-warning-icon">⚠️</span><div>{refiData.refinanceWarnings.map((w,i)=><div key={i} style={{marginBottom:i<refiData.refinanceWarnings.length-1?"0.4rem":0}}>{w}</div>)}</div></div>}
                </div>
              )}
            </div>

            {/* Federal */}
            <div className="fed-section">
              <div className="section-label"><span className="icon-badge purple">🏛️</span>Federal Repayment Plan Advisor</div>
              <div className="fed-intro">If you have <strong>federal loans</strong>, income-driven repayment plans can lower payments dramatically — and may lead to forgiveness.</div>
              <div className="fed-inputs">
                <div className="fed-field"><label>Loan Types</label><select value={fedLoansType} onChange={e=>setFedLoansType(e.target.value)}><option value="federal">All Federal</option><option value="mix">Mix Federal & Private</option><option value="private">All Private</option></select></div>
                <div className="fed-field"><label>Family Size</label><select value={fedFamilySize} onChange={e=>setFedFamilySize(e.target.value)}>{[1,2,3,4,5,6].map(n=><option key={n} value={String(n)}>{n} {n===1?"person":"people"}</option>)}</select></div>
                <div className="fed-field"><label>Filing Status</label><select value={fedFilingStatus} onChange={e=>setFedFilingStatus(e.target.value)}><option value="single">Single</option><option value="married_joint">Married Joint</option><option value="married_separate">Married Separate</option><option value="hoh">Head of Household</option></select></div>
              </div>
              {fedStatus==="idle"&&<button className="btn-fed" onClick={analyzeFederalPlans} disabled={fedLoansType==="private"}>🏛️ Analyze Federal Repayment Options</button>}
              {fedLoansType==="private"&&<div style={{fontSize:"0.82rem",color:"var(--text-light)",textAlign:"center",padding:"0.5rem"}}>Federal plans only apply to federal loans.</div>}
              {fedStatus==="searching"&&<div className="parsing-state"><div className="spinner purple"/><div className="parsing-label">Researching options…</div><div className="parsing-sub">Analyzing SAVE, IBR, PAYE, ICR & more with 2025 rules</div></div>}
              {fedStatus==="error"&&<div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">Try again or visit studentaid.gov/loan-simulator for official numbers.</div></div>}
              {fedStatus==="done"&&fedData&&(
                <>
                  {fedData.importantNote&&<div style={{fontSize:"0.82rem",color:"var(--purple)",background:"rgba(124,92,191,0.07)",border:"1.5px solid rgba(124,92,191,0.2)",borderRadius:"14px",padding:"0.85rem 1.1rem",marginBottom:"1rem",lineHeight:"1.55"}}>📢 {fedData.importantNote}</div>}
                  {fedData.topPickReason&&<div className="tip-item" style={{marginBottom:"1rem",background:"rgba(124,92,191,0.06)",border:"1.5px solid rgba(124,92,191,0.18)",borderRadius:"18px"}}><div className="tip-dot" style={{background:"var(--purple)"}}/><div className="tip-text"><strong style={{color:"var(--purple)"}}>Recommendation:</strong> {fedData.topPickReason}</div></div>}
                  <div className="fed-plans">{fedData.plans?.map((plan,i)=>(
                    <div key={i} className={`fed-plan-card ${plan.tier||"neutral"}`}>
                      <div className="fed-plan-header"><div><div className="fed-plan-name">{plan.emoji} {plan.name}</div></div><div className={`fed-plan-badge ${plan.tier==="top-pick"?"purple":plan.tier==="good"?"green":plan.tier==="caution"?"orange":"gray"}`}>{plan.badge}</div></div>
                      <div className="fed-plan-stats-row">
                        <div><div className="fed-plan-stat-label">Est. Monthly</div><div className={`fed-plan-stat-val ${plan.tier==="top-pick"?"purple":""}`}>{plan.estimatedMonthlyPayment?fmt(parseFloat(plan.estimatedMonthlyPayment)):"—"}</div></div>
                        <div><div className="fed-plan-stat-label">Payoff / Forgiveness</div><div className="fed-plan-stat-val">{plan.forgivenessPotential||"—"}</div></div>
                        <div><div className="fed-plan-stat-label">Est. Total Paid</div><div className={`fed-plan-stat-val ${plan.tier==="caution"?"red":"green"}`}>{plan.estimatedTotalPaid?fmt(parseFloat(plan.estimatedTotalPaid)):"—"}</div></div>
                      </div>
                      <div className="fed-plan-desc">{plan.description}</div>
                      {(plan.pros?.length||plan.cons?.length)&&<div className="fed-plan-pros-cons">{plan.pros?.map((p,j)=><div key={j} className="fed-pc-item pro">{p}</div>)}{plan.cons?.map((c,j)=><div key={j} className="fed-pc-item con">{c}</div>)}</div>}
                    </div>
                  ))}</div>
                  {fedData.pslfNote&&<div className="tip-item" style={{marginTop:"0.75rem"}}><div className="tip-dot" style={{background:"var(--purple)"}}/><div className="tip-text"><strong>PSLF:</strong> {fedData.pslfNote}</div></div>}
                  <div className="fed-disclaimer">⚠️ Estimates only. Use the official <strong>Loan Simulator at studentaid.gov</strong> before enrolling.</div>
                </>
              )}
            </div>

            {/* ── INTEREST ACCRUAL CALENDAR ── */}
            <div className="calendar-card">
              <div className="section-label"><span className="icon-badge orange">📅</span>Monthly Interest Calendar</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.25rem",lineHeight:"1.55"}}>Every month you carry these loans, this is exactly how much interest accrues. Nothing motivates faster payoff like seeing the cost in real time.</p>
              <div className="cal-total-row">
                <div>
                  <div className="cal-total-label">Interest accruing this year</div>
                  <div style={{fontSize:"0.75rem",color:"var(--text-light)",marginTop:"0.2rem"}}>Based on Avalanche strategy with {fmt(results.ex)}/mo extra</div>
                </div>
                <div className="cal-total-val">{fmt(interestCalendar?.annualInterest||0)}</div>
              </div>
              <div className="calendar-grid">
                {interestCalendar?.months.map((m,i) => (
                  <div className="cal-month" key={i}>
                    <div className="cal-month-name">{m.label}</div>
                    <div className="cal-month-interest">{fmt(m.interest)}</div>
                    <div className="cal-month-bar" style={{width:`${interestCalendar.maxInterest>0?(m.interest/interestCalendar.maxInterest*100):0}%`}}/>
                  </div>
                ))}
              </div>
              {interestCalendar?.loanTotals.length > 1 && (
                <>
                  <div style={{fontSize:"0.78rem",fontWeight:700,color:"var(--text-mid)",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:"0.6rem"}}>Annual interest by loan</div>
                  <div className="cal-breakdown">
                    {interestCalendar.loanTotals.map((l,i) => (
                      <div className="cal-loan-row" key={i}>
                        <span className="cal-loan-name">{l.name} ({l.rate}%)</span>
                        <div className="cal-loan-bar-wrap"><div className="cal-loan-bar-fill" style={{width:`${interestCalendar.annualInterest>0?(l.total/interestCalendar.annualInterest*100):0}%`,background:l.color}}/></div>
                        <span className="cal-loan-amount">{fmt(l.total)}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
              <div style={{display:"flex",gap:"0.5rem",marginTop:"1rem",justifyContent:"center"}}>
                <button className="btn-sm sage" onClick={()=>setCalYear(y=>Math.max(0,y-1))} disabled={calYear===0}>← Earlier</button>
                <span style={{padding:"0.45rem 1rem",fontSize:"0.78rem",fontWeight:700,color:"var(--text-mid)"}}>{calYear===0?"This year":`Year ${calYear+1}`}</span>
                <button className="btn-sm sage" onClick={()=>setCalYear(y=>y+1)}>Later →</button>
              </div>
            </div>

            {/* ── SALARY NEGOTIATION ROI ── */}
            <div className="salary-card">
              <div className="section-label"><span className="icon-badge blue">💼</span>Salary Negotiation ROI</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.5rem",lineHeight:"1.55"}}>A raise doesn't just mean more spending money — it can shave years off your debt. Here's exactly what negotiating a higher salary is worth to your payoff timeline.</p>
              <div className="salary-sliders">
                <div className="slider-group">
                  <label style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:"0.6rem"}}>
                    <span style={{fontSize:"0.78rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"var(--text-mid)"}}>Annual salary increase</span>
                    <span style={{fontFamily:"'Fraunces',serif",fontSize:"1.1rem",fontWeight:900,color:"var(--blue)"}}>{fmt(salaryRaise)}/yr</span>
                  </label>
                  <input type="range" className="blue-thumb" min={1000} max={30000} step={500} value={salaryRaise} onChange={e=>setSalaryRaise(Number(e.target.value))}
                    style={{background:`linear-gradient(to right, var(--blue) 0%, var(--blue) ${(salaryRaise-1000)/290}%, var(--cream) ${(salaryRaise-1000)/290}%, var(--cream) 100%)`}}/>
                </div>
                <div className="slider-group">
                  <label style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:"0.6rem"}}>
                    <span style={{fontSize:"0.78rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"var(--text-mid)"}}>% of raise applied to loans</span>
                    <span style={{fontFamily:"'Fraunces',serif",fontSize:"1.1rem",fontWeight:900,color:"var(--terracotta)"}}>{salaryApplyPct}%</span>
                  </label>
                  <input type="range" min={10} max={100} step={5} value={salaryApplyPct} onChange={e=>setSalaryApplyPct(Number(e.target.value))}
                    style={{background:`linear-gradient(to right, var(--terracotta) 0%, var(--terracotta) ${salaryApplyPct}%, var(--cream) ${salaryApplyPct}%, var(--cream) 100%)`}}/>
                </div>
              </div>
              {salaryROI && (
                <div className="salary-impact-grid">
                  <div className="salary-tile">
                    <div className="salary-tile-label">Monthly After-Tax</div>
                    <div className="salary-tile-val" style={{color:"var(--blue)"}}>{fmt(salaryROI.monthlyNet)}</div>
                    <div className="salary-tile-delta">after {(taxBracket*100).toFixed(0)}% tax</div>
                  </div>
                  <div className="salary-tile">
                    <div className="salary-tile-label">Applied to Loans</div>
                    <div className="salary-tile-val" style={{color:"var(--terracotta)"}}>{fmt(salaryROI.appliedMonthly)}/mo</div>
                    <div className="salary-tile-delta">{salaryApplyPct}% of take-home raise</div>
                  </div>
                  <div className="salary-tile">
                    <div className="salary-tile-label">Months Saved</div>
                    <div className={`salary-tile-val${salaryROI.monthsSaved>0?" green":""}`}>{salaryROI.monthsSaved>0?`−${fmtYM(salaryROI.monthsSaved)}`:"—"}</div>
                    {salaryROI.monthsSaved>0&&<div className="salary-tile-delta">vs. your current plan</div>}
                  </div>
                  <div className="salary-tile">
                    <div className="salary-tile-label">Interest Saved</div>
                    <div className={`salary-tile-val${salaryROI.interestSaved>0?" green":""}`}>{salaryROI.interestSaved>0?fmt(salaryROI.interestSaved):"—"}</div>
                    {salaryROI.interestSaved>0&&<div className="salary-tile-delta">in total interest</div>}
                  </div>
                </div>
              )}
              <div style={{fontSize:"0.78rem",color:"var(--text-light)",marginTop:"1rem",lineHeight:"1.55",padding:"0.85rem 1rem",background:"var(--cream)",borderRadius:"14px"}}>
                💡 Use this as your business case for your next performance review. If you can shave {salaryROI&&salaryROI.monthsSaved>0?fmtYM(salaryROI.monthsSaved):"months"} off debt just from a raise, that negotiation is worth every awkward minute.
              </div>
            </div>

            {/* ── LOAN FORGIVENESS CHECKER ── */}
            <div className="forgive-card">
              <div className="section-label"><span className="icon-badge sage">🎓</span>Loan Forgiveness Eligibility</div>
              <div className="forgive-intro">Beyond PSLF, dozens of programs forgive student debt based on your <strong>profession, employer, or location</strong>. Tell us about your work and we'll search every program you might qualify for.</div>
              <div className="forgive-inputs">
                <div className="forgive-field">
                  <label>Employer Type</label>
                  <select value={forgiveEmployer} onChange={e=>setForgiveEmployer(e.target.value)}>
                    <option value="government">Government (federal/state/local)</option>
                    <option value="nonprofit_501c3">Nonprofit 501(c)(3)</option>
                    <option value="public_school">Public School / Education</option>
                    <option value="hospital_nonprofit">Nonprofit Hospital / Healthcare</option>
                    <option value="military">Military</option>
                    <option value="private_for_profit">Private For-Profit</option>
                    <option value="self_employed">Self-Employed / Freelance</option>
                    <option value="other_nonprofit">Other Nonprofit</option>
                  </select>
                </div>
                <div className="forgive-field">
                  <label>Years in This Role</label>
                  <select value={forgiveYears} onChange={e=>setForgiveYears(e.target.value)}>
                    {["< 1","1","2","3","4","5","6","7","8","9","10+"].map(y=><option key={y} value={y}>{y} year{y==="1"?"":"s"}</option>)}
                  </select>
                </div>
                <div className="forgive-field">
                  <label>Job Title / Field</label>
                  <input type="text" placeholder="e.g. Teacher, Nurse, Social Worker" value={forgiveJobTitle} onChange={e=>setForgiveJobTitle(e.target.value)}/>
                </div>
                <div className="forgive-field" style={{display:"flex",alignItems:"flex-end"}}>
                  {forgiveStatus==="idle"||forgiveStatus==="error" ? (
                    <button className="btn-forgive" style={{width:"100%"}} onClick={searchForgiveness}>🎓 Check My Eligibility</button>
                  ) : forgiveStatus==="searching" ? (
                    <div className="parsing-state" style={{width:"100%",padding:"0.6rem"}}><div className="spinner sage"/><div className="parsing-label" style={{fontSize:"0.82rem"}}>Searching programs…</div></div>
                  ) : (
                    <button className="btn-forgive" style={{width:"100%",opacity:0.7,fontSize:"0.85rem"}} onClick={()=>{setForgiveStatus("idle");setForgiveData(null);}}>🔄 Search Again</button>
                  )}
                </div>
              </div>
              {forgiveStatus==="error"&&<div className="parse-error"><span className="parse-error-icon">⚠️</span><div className="parse-error-text">Couldn't search programs. Try again.</div></div>}
              {forgiveStatus==="done"&&forgiveData&&(
                <>
                  {forgiveData.summary&&<div className="tip-item" style={{marginBottom:"1rem",background:"rgba(90,138,106,0.06)",border:"1.5px solid rgba(90,138,106,0.18)",borderRadius:"18px"}}><div className="tip-dot" style={{background:"var(--sage)"}}/><div className="tip-text">{forgiveData.summary}</div></div>}
                  <div className="forgive-programs">
                    {forgiveData.programs?.map((p,i)=>(
                      <div key={i} className={`forgive-program-card ${p.eligibility||"unlikely"}`}>
                        <div className="fp-header">
                          <div className="fp-name">{p.name}</div>
                          <div className={`fp-badge ${p.eligibility==="eligible"?"green":p.eligibility==="maybe"?"gold":"gray"}`}>{p.badge}</div>
                        </div>
                        <div className="fp-stats">
                          <div><div className="fp-stat-label">Forgiveness Amount</div><div className={`fp-stat-val ${p.eligibility==="eligible"?"green":p.eligibility==="maybe"?"gold":""}`}>{p.forgivenessAmount||"—"}</div></div>
                          <div><div className="fp-stat-label">Timeline</div><div className="fp-stat-val">{p.timeline||"—"}</div></div>
                          <div><div className="fp-stat-label">Requirements</div><div className="fp-stat-val" style={{fontSize:"0.78rem",fontWeight:600,color:"var(--text-mid)",lineHeight:1.3}}>{p.requirementsMet||"—"}</div></div>
                        </div>
                        <div className="fp-desc">{p.description}</div>
                        {p.nextStep&&<div style={{marginTop:"0.6rem",fontSize:"0.78rem",fontWeight:700,color:"var(--text-mid)"}}>→ {p.nextStep}</div>}
                        {p.learnMoreUrl&&<a className="fp-action" href={p.learnMoreUrl} target="_blank" rel="noopener noreferrer">Learn more ↗</a>}
                      </div>
                    ))}
                  </div>
                  <div className="fed-disclaimer">⚠️ Eligibility depends on your specific loan types (must be Direct Loans for most federal programs), employer certification, and repayment plan. Consult your servicer or studentaid.gov for official determination.</div>
                </>
              )}
            </div>

            {/* ── PARTNER MODE ── */}
            <div className="partner-card">
              <div className="section-label"><span className="icon-badge pink">👫</span>Partner / Dual Income Mode</div>
              <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.25rem",lineHeight:"1.55"}}>Combining households? Add your partner's loans to see a unified payoff plan and how your combined income changes the picture.</p>
              <div className="partner-toggle-row">
                <button className={`partner-toggle${!partnerActive?" active":""}`} onClick={()=>setPartnerActive(false)}>Solo view</button>
                <button className={`partner-toggle${partnerActive?" active":""}`} onClick={()=>setPartnerActive(true)}>Combined household 👫</button>
              </div>
              {partnerActive && (
                <>
                  <div className="partner-grid">
                    <div>
                      <div className="partner-col-title you">Your Loans</div>
                      {loans.filter(l=>parseFloat(l.balance)>0).map(l=>(
                        <div key={l.id} style={{display:"flex",justifyContent:"space-between",fontSize:"0.82rem",padding:"0.35rem 0",borderBottom:"1px solid var(--border)"}}>
                          <span style={{color:"var(--text-mid)"}}>{l.name||"Loan"}</span>
                          <span style={{fontWeight:700}}>{fmt(parseFloat(l.balance)||0)} @ {l.rate}%</span>
                        </div>
                      ))}
                      <div style={{marginTop:"0.75rem"}}>
                        <div className="field-group"><label>Your income (take-home)</label><input type="number" value={income} onChange={e=>setIncome(e.target.value)} placeholder="5200"/></div>
                      </div>
                    </div>
                    <div>
                      <div className="partner-col-title them">Partner's Loans</div>
                      {partnerLoans.map((loan,i)=>(
                        <div className="partner-mini-row" key={loan.id} style={{marginBottom:"0.5rem"}}>
                          <input placeholder="Loan name" value={loan.name} onChange={e=>updatePartnerLoan(loan.id,"name",e.target.value)}/>
                          <input type="number" placeholder="Balance" value={loan.balance} onChange={e=>updatePartnerLoan(loan.id,"balance",e.target.value)}/>
                          <input type="number" placeholder="Rate %" step="0.01" value={loan.rate} onChange={e=>updatePartnerLoan(loan.id,"rate",e.target.value)}/>
                        </div>
                      ))}
                      <button className="btn-add" style={{fontSize:"0.78rem",marginBottom:"0.75rem"}} onClick={addPartnerLoan}>＋ Add loan</button>
                      <div className="field-group"><label>Partner's income (take-home)</label><input type="number" value={partnerIncome} onChange={e=>setPartnerIncome(e.target.value)} placeholder="4000"/></div>
                    </div>
                  </div>
                  {partnerResults && (
                    <div className="partner-result-grid">
                      <div className="partner-res-tile">
                        <div className="partner-res-label">Combined Total Debt</div>
                        <div className="partner-res-val">{fmt(partnerResults.totalDebt)}</div>
                        <div style={{fontSize:"0.72rem",color:"var(--text-light)",marginTop:"0.2rem"}}>Across all loans</div>
                      </div>
                      <div className="partner-res-tile">
                        <div className="partner-res-label">Combined Payoff (Avalanche)</div>
                        <div className="partner-res-val" style={{color:"var(--terracotta)"}}>{fmtYM(partnerResults.combined.months)}</div>
                        <div style={{fontSize:"0.72rem",color:"var(--text-light)",marginTop:"0.2rem"}}>With {fmt(parseFloat(extra)||0)}/mo extra</div>
                      </div>
                      <div className="partner-res-tile">
                        <div className="partner-res-label">Combined Income</div>
                        <div className="partner-res-val green">{fmt(partnerResults.combinedIncome)}/mo</div>
                        <div style={{fontSize:"0.72rem",color:"var(--text-light)",marginTop:"0.2rem"}}>{((partnerResults.totalMin/partnerResults.combinedIncome)*100).toFixed(0)}% DTI ratio</div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* ── PAYOFF ORDER STEP-BY-STEP ── */}
            {payoffOrder?.length > 0 && (
              <div className="payoff-order-card">
                <div className="section-label"><span className="icon-badge sage">🗺️</span>Your Debt-Free Roadmap</div>
                <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.5rem",lineHeight:"1.55"}}>Avalanche strategy — exactly which loan to attack first, when it'll be gone, and how to roll that freed cash into the next one.</p>
                <div className="payoff-timeline">
                  {payoffOrder.map((step, i) => {
                    const colors = ["#D96C45","#5B7FA6","#5A8A6A","#C89A2A","#7C5CBF","#C05A8A"];
                    const color = colors[i % colors.length];
                    const isLast = i === payoffOrder.length - 1;
                    return (
                      <div className="payoff-step" key={i}>
                        <div className="payoff-step-left">
                          <div className="payoff-step-num" style={{background:color}}>{step.stepNum}</div>
                          {!isLast && <div className="payoff-step-line"/>}
                        </div>
                        <div className="payoff-step-body" style={{border:`1.5px solid ${color}22`}}>
                          <div className="payoff-step-title" style={{color}}>{step.name} paid off! 🎯</div>
                          <div className="payoff-step-date">Month {step.month} · {step.date}</div>
                          <div className="payoff-step-stats">
                            <div className="payoff-step-stat"><strong>{step.rate}%</strong> rate</div>
                            <div className="payoff-step-stat">Paid <strong>{fmt(step.interestPaid)}</strong> in interest</div>
                            <div className="payoff-step-stat">Frees up <strong>{fmt(step.freed)}/mo</strong></div>
                          </div>
                          <div className="payoff-step-action">→ {step.action}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div style={{background:"rgba(90,138,106,0.07)",border:"1.5px solid rgba(90,138,106,0.2)",borderRadius:"16px",padding:"1rem 1.25rem",marginTop:"0.5rem",fontSize:"0.83rem",color:"var(--text-mid)",lineHeight:"1.6"}}>
                  💡 The key to Avalanche is the <strong>debt rollover</strong> — every time a loan dies, its minimum payment becomes extra firepower on the next one. By your final loan you're firing everything.
                </div>
              </div>
            )}

            {/* ── FULL AMORTIZATION TABLE ── */}
            {amortData?.length > 0 && (
              <div className="amort-card">
                <div className="section-label"><span className="icon-badge blue">📋</span>Full Amortization Table</div>
                <p style={{fontSize:"0.82rem",color:"var(--text-mid)",marginBottom:"1.25rem",lineHeight:"1.55"}}>Every payment, every month — see exactly how much goes to interest vs. principal for each loan.</p>
                <div className="amort-tabs">
                  {amortData.map((loan,i)=>(
                    <button key={i} className={`amort-tab${amortLoanIdx===i?" active":""}`} onClick={()=>{setAmortLoanIdx(i);setAmortPage(0);}}>{loan.name}</button>
                  ))}
                </div>
                {amortData[amortLoanIdx] && (() => {
                  const loan = amortData[amortLoanIdx];
                  const start = amortPage * AMORT_PAGE_SIZE;
                  const pageRows = loan.rows.slice(start, start + AMORT_PAGE_SIZE);
                  const totalPages = Math.ceil(loan.rows.length / AMORT_PAGE_SIZE);
                  const startDate = new Date();
                  return (
                    <>
                      <div className="amort-summary-row">
                        <div className="amort-sum-tile"><div className="amort-sum-label">Payoff Timeline</div><div className="amort-sum-val">{fmtYM(loan.months)}</div></div>
                        <div className="amort-sum-tile"><div className="amort-sum-label">Total Interest</div><div className="amort-sum-val red">{fmt(loan.totalInterest)}</div></div>
                        <div className="amort-sum-tile"><div className="amort-sum-label">Total Paid</div><div className="amort-sum-val">{fmt(loan.totalPrincipal + loan.totalInterest)}</div></div>
                      </div>
                      <div className="amort-table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <th>Month</th>
                              <th>Date</th>
                              <th>Payment</th>
                              <th>Principal</th>
                              <th>Interest</th>
                              <th>Balance</th>
                            </tr>
                          </thead>
                          <tbody>
                            {pageRows.map((row) => {
                              const d = new Date(startDate);
                              d.setMonth(d.getMonth() + row.month - 1);
                              const pctPrincipal = row.payment > 0 ? (row.principal / row.payment * 100).toFixed(0) : 0;
                              return (
                                <tr key={row.month}>
                                  <td>{row.month}</td>
                                  <td style={{color:"var(--text-light)"}}>{d.toLocaleDateString('en-US',{month:'short',year:'numeric'})}</td>
                                  <td>{fmt(row.payment)}</td>
                                  <td className="td-principal">{fmt(row.principal)} <span style={{fontSize:"0.68rem",opacity:0.7}}>({pctPrincipal}%)</span></td>
                                  <td className="td-interest">{fmt(row.interest)}</td>
                                  <td className="td-balance">{fmt(row.balance)}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                      <div className="amort-pagination">
                        <button className="btn-sm sage" disabled={amortPage===0} onClick={()=>setAmortPage(p=>p-1)}>← Prev</button>
                        <span>Page {amortPage+1} of {totalPages} · Rows {start+1}–{Math.min(start+AMORT_PAGE_SIZE, loan.rows.length)} of {loan.rows.length}</span>
                        <button className="btn-sm sage" disabled={amortPage>=totalPages-1} onClick={()=>setAmortPage(p=>p+1)}>Next →</button>
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {/* Tips */}
            <div className="card">
              <div className="section-label"><span className="icon-badge orange">💡</span>Personalized Insights</div>
              <div className="tips-grid">{results.tips.map((t,i)=><div className="tip-item" key={i}><div className="tip-dot"/><div className="tip-text">{t}</div></div>)}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

